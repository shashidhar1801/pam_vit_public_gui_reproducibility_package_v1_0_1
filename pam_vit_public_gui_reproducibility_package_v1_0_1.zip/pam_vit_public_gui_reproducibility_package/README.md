# PAM-ViT Public GUI Reproducibility Package

This archive is the portable deployment export for the Taiwanese white dolphin Dual-Band
PAM-ViT-Lite public GUI.

## Included components

- `app/`: deployable GUI application with the live manuscript checkpoint already in place
- `artifacts/`: original reproducibility artifacts supplied for this project
- `checksums/`: package-level SHA-256 manifest plus the original artifact checksum file
- `docs/`: deployment guide, transfer checklist, and manuscript-alignment note

## Fast start

```bash
cd app
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install torch
python app.py
```

Then open:

- `http://127.0.0.1:8000`

## Live-mode check

```bash
curl http://127.0.0.1:8000/api/status
```

Expected:

- `model_live: true`
- `badge: "Live manuscript model"`

## Main docs

- `docs/DEPLOYMENT.md`
- `docs/TRANSFER_CHECKLIST.md`
- `docs/MANUSCRIPT_ALIGNMENT.md`
