# Manuscript Alignment Note

This package supports the manuscript section on implementation and reproducibility for the
Taiwanese white dolphin Dual-Band PAM-ViT-Lite detector.

## Manuscript Cross-References

- Main manuscript Section 2.10 describes implementation, checkpointing, and deployment reproducibility.
- Supplementary Methods S6 describes the public deployment and transfer package.
- Supplementary Table S5 reports the main training and inference hyperparameters.
- The GUI package is intended for public screening and external-machine deployment, not as a new
  experimental condition.

## Public Package Checkpoint Naming

Supplementary Table S5 records the final model lineage as
`dual_band_pam_vit_tf2_adapt_025s_trained.pt`. The same final manuscript model is archived in this
public GUI package under the deployment-friendly filename:

```text
app/models/dual_band_pam_vit_lite_final.pt
artifacts/dual_band_pam_vit_lite_final.pt
```

Both packaged checkpoint copies have the same SHA-256 hash:

```text
8517aa6700395c82b6716b00be8d3a0fac5247f3cc478b89766f0033db930488
```

## Inference Settings

The GUI uses the final challenge-adapted 0.25 s inference configuration:

- Sample rate: 96 kHz
- Whistle band: 3-10 kHz
- Click band: 10-40 kHz
- Window / stride: 0.25 s / 0.25 s
- Click micro-windows: 4
- Whistle threshold: 0.70
- Click threshold: 0.45

These values match Supplementary Methods S6 and Supplementary Table S5.

## Training Record

The nested archive `artifacts/dual_band_pam_vit_lite_reproducibility_bundle.zip` is the
authoritative training and checkpoint-lineage record. It contains:

- staged training configs for the base, hard-negative, and challenge-adaptation stages
- checkpoint lineage files
- scripts for training, inference, and evaluation
- label metadata and expected inference outputs
- summary outputs and threshold records

The outer `app/model_repo/configs/` YAML files are retained for public code readability and now use
the same manuscript-facing staged hyperparameter values.

## Raw Audio Availability

The package is designed so users can run the trained detector on new 96-kHz WAV recordings without
access to restricted raw marine-audio archives. Where raw audio cannot be redistributed, the
reproducibility path is:

1. use the supplied code, final checkpoint, configuration files, labels, expected outputs, and
   checksums;
2. verify the package with `checksums/package_sha256_manifest.txt`;
3. run the GUI or command-line inference on user-supplied 96-kHz WAV recordings;
4. compare exported CSV/JSON outputs against the documented output schema.
