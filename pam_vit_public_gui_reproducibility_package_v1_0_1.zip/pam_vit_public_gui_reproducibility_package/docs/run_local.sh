#!/usr/bin/env sh
set -eu

PORT_VALUE="${PORT:-8000}"

cd "$(dirname "$0")/../app"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi

. .venv/bin/activate
pip install -r requirements.txt
python app.py
