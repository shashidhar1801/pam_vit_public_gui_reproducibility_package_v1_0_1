# Transfer Checklist

Before copying the deployment package to another machine:

1. Verify the package ZIP exists.
2. Verify the package-level SHA-256 manifest exists.
3. Verify the live checkpoint is present in `app/models/`.
4. Verify `curl http://127.0.0.1:8000/api/status` reports `model_live: true` on the source machine.

After copying to another machine:

1. Unzip the package.
2. Run the app with Python or Docker.
3. Check `/api/status`.
4. Upload a short WAV file to confirm end-to-end inference.

