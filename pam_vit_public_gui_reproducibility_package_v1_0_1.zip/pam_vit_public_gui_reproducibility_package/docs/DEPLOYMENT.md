# Dual-Band PAM-ViT GUI Deployment Guide

## What this package contains

This package is meant to move the full GUI deployment workflow to another machine with minimal
guesswork.

It includes:

- the public-facing web GUI
- the live manuscript checkpoint
- the bundled Dual-Band PAM-ViT-Lite model code used by the GUI
- the original reproducibility bundle ZIP
- the original artifact checksum JSON
- a package-level SHA-256 manifest

## Recommended machine requirements

Minimum:

- macOS or Linux
- Python 3.11 or newer
- 4 GB RAM

Preferred:

- 8 GB RAM
- Python 3.11 or 3.12

## Option A: run directly with Python

```bash
cd app
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install torch
python app.py
```

Then open:

- `http://127.0.0.1:8000`

If port `8000` is busy:

```bash
PORT=8010 python app.py
```

## Option B: run with Conda

```bash
cd app
conda create -n pamvit-gui python=3.11 -y
conda activate pamvit-gui
pip install -r requirements.txt
pip install torch
python app.py
```

## Option C: run with Docker

The shipped `Dockerfile` installs the web stack. If you want live inference, make sure the image
also gets a working PyTorch install for the target platform.

```bash
cd app
docker build -t pam-vit-gui .
docker run --rm -p 8000:8000 pam-vit-gui
```

## Environment variables

The app already expects the final checkpoint in:

```text
app/models/dual_band_pam_vit_lite_final.pt
```

You can override this with:

```bash
export PAM_VIT_CHECKPOINT=/absolute/path/to/dual_band_pam_vit_lite_final.pt
export PAM_VIT_CONFIG=/absolute/path/to/adaptation_stage.yaml
```

## Health check

After the server starts:

```bash
curl http://127.0.0.1:8000/api/status
```

Expected live-mode response:

- `model_live: true`
- `badge: "Live manuscript model"`

## Main package layout

```text
pam_vit_public_gui_reproducibility_package/
├── app/
├── artifacts/
├── checksums/
└── docs/
```

## Notes

- `artifacts/dual_band_pam_vit_lite_reproducibility_bundle.zip` is preserved exactly as supplied.
- `checksums/original_artifact_checksums.json` preserves the original artifact hashes.
- The GUI package removes previous run outputs so deployment starts clean.
- The app writes new inference outputs into `app/runs/` at runtime.
