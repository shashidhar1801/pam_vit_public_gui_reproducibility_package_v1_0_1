from __future__ import annotations

import json
import os
import secrets
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np
import pandas as pd
import scipy.signal as signal
import soundfile as sf
from sklearn.metrics import average_precision_score, precision_recall_fscore_support, roc_auc_score
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename


matplotlib.use("Agg")
from matplotlib import pyplot as plt


class PAMPublicService:
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.runs_dir = self.base_dir / "runs"
        self.runs_dir.mkdir(parents=True, exist_ok=True)
        self.model_repo_dir = self.base_dir / "model_repo"
        self.models_dir = self.base_dir / "models"
        self.default_config = Path(
            os.getenv(
                "PAM_VIT_CONFIG",
                str(self.model_repo_dir / "configs" / "adaptation_stage.yaml"),
            )
        )
        self.default_checkpoint = Path(
            os.getenv(
                "PAM_VIT_CHECKPOINT",
                str(self.models_dir / "dual_band_pam_vit_lite_final.pt"),
            )
        )

    def status(self) -> dict[str, Any]:
        torch_available, torch_error = self._torch_ready()
        repo_ready = (self.model_repo_dir / "dual_band_pam_vit_lite").exists()
        config_ready = self.default_config.exists()
        checkpoint_ready = self.default_checkpoint.exists()
        load_ready = False
        load_error = None
        if torch_available and repo_ready and config_ready and checkpoint_ready:
            load_ready, load_error = self._model_loader_ready()
        model_live = torch_available and repo_ready and config_ready and checkpoint_ready and load_ready

        reasons = []
        if not repo_ready:
            reasons.append("model package missing")
        if not config_ready:
            reasons.append("config missing")
        if not checkpoint_ready:
            reasons.append("checkpoint missing")
        if not torch_available:
            reasons.append("PyTorch runtime missing")
        if torch_available and repo_ready and config_ready and checkpoint_ready and not load_ready:
            reasons.append("checkpoint could not be loaded by the current app runtime")

        if model_live:
            badge = "Live manuscript model"
            description = "Real Dual-Band PAM-ViT-Lite inference is available for public screening."
        else:
            badge = "Preview mode"
            description = (
                "Acoustic preview is available now. Add a compatible checkpoint and PyTorch runtime "
                "to switch the app into full manuscript-model inference."
            )

        return {
            "model_live": model_live,
            "badge": badge,
            "description": description,
            "config_path": str(self.default_config),
            "checkpoint_path": str(self.default_checkpoint),
            "reasons": reasons,
            "runtime_detail": load_error or torch_error,
        }

    def analyze_upload(
        self,
        audio_file: FileStorage,
        whistle_csv: FileStorage | None = None,
        click_csv: FileStorage | None = None,
    ) -> dict[str, Any]:
        run_id = f"{datetime.now().strftime('%Y%m%d-%H%M%S')}-{secrets.token_hex(4)}"
        run_dir = self.runs_dir / run_id
        upload_dir = run_dir / "input"
        upload_dir.mkdir(parents=True, exist_ok=True)

        audio_upload_path = self._save_upload(audio_file, upload_dir)
        audio_path = self._resolve_audio(audio_upload_path, upload_dir)

        whistle_path = self._save_optional_upload(whistle_csv, upload_dir)
        click_path = self._save_optional_upload(click_csv, upload_dir)

        info = sf.info(str(audio_path))
        audio_meta = {
            "filename": audio_path.name,
            "duration_sec": round(float(info.duration), 2),
            "duration_label": self._format_seconds(float(info.duration)),
            "sample_rate_hz": int(info.samplerate),
            "channels": int(info.channels),
            "format": info.format,
            "subtype": info.subtype,
        }

        spectrogram_path = run_dir / "spectrogram_preview.png"
        self._build_spectrogram_preview(audio_path, spectrogram_path)

        runtime = self.status()
        warnings: list[str] = []

        if runtime["model_live"]:
            try:
                result = self._run_model_analysis(audio_path, run_dir)
            except Exception as exc:
                warnings.append(
                    "The manuscript checkpoint is not active in this runtime, so the app returned "
                    "an acoustic preview instead."
                )
                warnings.append(f"Fallback reason: {exc.__class__.__name__}")
                result = self._run_preview_analysis(audio_path, run_dir)
        else:
            result = self._run_preview_analysis(audio_path, run_dir)

        notes = self._build_audio_notes(audio_meta)
        notes.extend(warnings)
        if result["mode"] == "preview":
            notes.append(
                "Preview mode uses band-limited acoustic activity and transient proxies, not the "
                "final Dual-Band PAM-ViT-Lite checkpoint."
            )

        evaluation = None
        if result["mode"] == "model" and (whistle_path or click_path):
            evaluation = self._evaluate_predictions(result["window_df"], whistle_path, click_path)
            if evaluation is not None:
                with open(run_dir / "evaluation.json", "w", encoding="utf-8") as handle:
                    json.dump(evaluation, handle, indent=2)

        window_csv = run_dir / "window_predictions.csv"
        whistle_csv_out = run_dir / "whistle_intervals.csv"
        click_csv_out = run_dir / "click_intervals.csv"
        per_min_csv = run_dir / "per_minute_summary.csv"
        summary_json = run_dir / "analysis_summary.json"

        result["window_df"].to_csv(window_csv, index=False)
        result["whistle_intervals_df"].to_csv(whistle_csv_out, index=False)
        result["click_intervals_df"].to_csv(click_csv_out, index=False)
        result["per_minute_df"].to_csv(per_min_csv, index=False)

        serializable_summary = {
            "run_id": run_id,
            "mode": result["mode"],
            "audio": audio_meta,
            "summary_cards": result["summary_cards"],
            "notes": notes,
        }
        with open(summary_json, "w", encoding="utf-8") as handle:
            json.dump(serializable_summary, handle, indent=2)

        return {
            "run_id": run_id,
            "mode": result["mode"],
            "mode_label": result["mode_label"],
            "headline": result["headline"],
            "audio": audio_meta,
            "notes": notes,
            "summary_cards": result["summary_cards"],
            "spectrogram_url": f"/runs/{run_id}/spectrogram_preview.png",
            "downloads": [
                {
                    "label": "Window predictions CSV",
                    "url": f"/runs/{run_id}/window_predictions.csv?download=1",
                },
                {
                    "label": "Whistle intervals CSV",
                    "url": f"/runs/{run_id}/whistle_intervals.csv?download=1",
                },
                {
                    "label": "Click intervals CSV",
                    "url": f"/runs/{run_id}/click_intervals.csv?download=1",
                },
                {
                    "label": "Per-minute summary CSV",
                    "url": f"/runs/{run_id}/per_minute_summary.csv?download=1",
                },
                {
                    "label": "Summary JSON",
                    "url": f"/runs/{run_id}/analysis_summary.json?download=1",
                },
            ],
            "series": result["series"],
            "intervals": {
                "whistles": self._table_rows(result["whistle_intervals_df"]),
                "clicks": self._table_rows(result["click_intervals_df"]),
            },
            "per_minute": self._per_minute_rows(result["per_minute_df"]),
            "evaluation": evaluation,
        }

    def resolve_run_file(self, run_id: str, filename: str) -> Path | None:
        candidate = (self.runs_dir / run_id / filename).resolve()
        if not candidate.exists() or not candidate.is_file():
            return None
        if self.runs_dir.resolve() not in candidate.parents:
            return None
        return candidate

    def _save_upload(self, upload: FileStorage, output_dir: Path) -> Path:
        safe_name = secure_filename(upload.filename or "recording.wav")
        suffix = Path(safe_name).suffix.lower()
        if suffix not in {".wav", ".zip"}:
            raise ValueError("Accepted inputs are WAV files or ZIP archives that contain a WAV file.")
        target = output_dir / safe_name
        upload.save(target)
        return target

    def _save_optional_upload(self, upload: FileStorage | None, output_dir: Path) -> Path | None:
        if upload is None or not upload.filename:
            return None
        safe_name = secure_filename(upload.filename)
        if Path(safe_name).suffix.lower() != ".csv":
            raise ValueError("Reference files must be CSV files.")
        target = output_dir / safe_name
        upload.save(target)
        return target

    def _resolve_audio(self, upload_path: Path, output_dir: Path) -> Path:
        if upload_path.suffix.lower() != ".zip":
            return upload_path

        with zipfile.ZipFile(upload_path, "r") as archive:
            wav_members = [
                member
                for member in archive.infolist()
                if not member.is_dir() and member.filename.lower().endswith(".wav")
            ]
            if not wav_members:
                raise ValueError("The ZIP archive does not contain a WAV file.")
            chosen = wav_members[0]
            extracted_name = secure_filename(Path(chosen.filename).name) or "unzipped_recording.wav"
            target = output_dir / extracted_name
            with archive.open(chosen, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            return target

    def _run_model_analysis(self, audio_path: Path, run_dir: Path) -> dict[str, Any]:
        if str(self.model_repo_dir) not in sys.path:
            sys.path.insert(0, str(self.model_repo_dir))

        import torch
        from dual_band_pam_vit_lite.config import ExperimentConfig
        from dual_band_pam_vit_lite.features import click_features, whistle_features
        from dual_band_pam_vit_lite.metrics import merge_positive_windows_to_intervals
        from dual_band_pam_vit_lite.model import DualBandPAMViTLite

        cfg = ExperimentConfig.from_yaml(str(self.default_config))
        model = DualBandPAMViTLite.from_checkpoint(str(self.default_checkpoint))
        device = torch.device("cpu")
        model = model.to(device)
        model.eval()

        info = sf.info(str(audio_path))
        sr = info.samplerate
        duration = float(info.duration)
        starts = np.arange(
            0.0,
            max(0.0, duration - cfg.feature.window_sec) + 1e-9,
            cfg.feature.stride_sec,
        )
        if len(starts) == 0:
            starts = np.array([0.0], dtype=np.float64)

        rows = []
        n_samples = int(round(cfg.feature.window_sec * sr))
        with sf.SoundFile(str(audio_path), "r") as handle:
            for start_time in starts:
                handle.seek(int(round(start_time * sr)))
                wave = handle.read(n_samples, dtype="float32", always_2d=False)
                if getattr(wave, "ndim", 1) > 1:
                    wave = wave.mean(axis=1)
                if len(wave) < n_samples:
                    wave = np.pad(wave, (0, n_samples - len(wave)))

                whistle_x = torch.from_numpy(whistle_features(wave, sr, cfg.feature))[None].to(device)
                click_x = torch.from_numpy(click_features(wave, sr, cfg.feature))[None].to(device)
                with torch.no_grad():
                    out = model(whistle_x, click_x)
                    whistle_prob = torch.sigmoid(out["whistle_logit"])[0].item()
                    click_prob = torch.sigmoid(out["click_logit"])[0].item()
                    click_count = torch.expm1(out["count_logit"]).clamp(min=0)[0].item()

                rows.append(
                    {
                        "start_time_s": float(start_time),
                        "end_time_s": float(start_time + cfg.feature.window_sec),
                        "whistle_score": whistle_prob,
                        "click_score": click_prob,
                        "count_score": click_count,
                        "whistle_pred": int(whistle_prob >= cfg.threshold_whistle),
                        "click_pred": int(click_prob >= cfg.threshold_click),
                    }
                )

        window_df = pd.DataFrame(rows)
        whistle_intervals_df = merge_positive_windows_to_intervals(window_df, "whistle_pred")
        click_intervals_df = merge_positive_windows_to_intervals(window_df, "click_pred")
        per_minute_df = self._per_minute_summary(window_df)

        summary_cards = [
            self._card("Whistle-positive windows", int(window_df["whistle_pred"].sum()), "Thresholded manuscript-model detections"),
            self._card("Click-positive windows", int(window_df["click_pred"].sum()), "Thresholded manuscript-model detections"),
            self._card("Whistle intervals", len(whistle_intervals_df), "Merged whistle-positive windows"),
            self._card("Click intervals", len(click_intervals_df), "Merged click-positive windows"),
            self._card("Click-count sum", round(float(window_df["count_score"].sum()), 1), "Regression head total"),
            self._card("Mean whistle probability", round(float(window_df["whistle_score"].mean()), 3), "Average model confidence"),
            self._card("Mean click probability", round(float(window_df["click_score"].mean()), 3), "Average model confidence"),
        ]

        return {
            "mode": "model",
            "mode_label": "Live manuscript model",
            "headline": "Dual-Band PAM-ViT-Lite manuscript checkpoint results",
            "window_df": window_df,
            "whistle_intervals_df": whistle_intervals_df,
            "click_intervals_df": click_intervals_df,
            "per_minute_df": per_minute_df,
            "summary_cards": summary_cards,
            "series": self._series_payload(
                window_df,
                whistle_label="Whistle probability",
                click_label="Click probability",
                count_label="Click-count estimate",
            ),
        }

    def _run_preview_analysis(self, audio_path: Path, run_dir: Path) -> dict[str, Any]:
        info = sf.info(str(audio_path))
        sr = info.samplerate
        duration = float(info.duration)
        window_sec = 1.0
        stride_sec = 1.0
        starts = np.arange(0.0, max(0.0, duration - window_sec) + 1e-9, stride_sec)
        if len(starts) == 0:
            starts = np.array([0.0], dtype=np.float64)

        whistle_raw = []
        click_raw = []
        transient_raw = []
        rows = []

        n_samples = max(1, int(round(window_sec * sr)))
        with sf.SoundFile(str(audio_path), "r") as handle:
            for start_time in starts:
                handle.seek(int(round(start_time * sr)))
                wave = handle.read(n_samples, dtype="float32", always_2d=False)
                if getattr(wave, "ndim", 1) > 1:
                    wave = wave.mean(axis=1)
                if len(wave) < n_samples:
                    wave = np.pad(wave, (0, n_samples - len(wave)))
                w_score, c_score, transient = self._preview_window_scores(wave, sr)
                whistle_raw.append(w_score)
                click_raw.append(c_score)
                transient_raw.append(transient)

        whistle_series = self._sigmoid_scale(np.asarray(whistle_raw, dtype=np.float64))
        click_series = self._sigmoid_scale(np.asarray(click_raw, dtype=np.float64))
        transient_series = self._positive_scale(np.asarray(transient_raw, dtype=np.float64))

        whistle_pred = (whistle_series >= 0.62).astype(int)
        click_pred = (click_series >= 0.68).astype(int)

        for idx, start_time in enumerate(starts):
            rows.append(
                {
                    "start_time_s": float(start_time),
                    "end_time_s": float(start_time + window_sec),
                    "whistle_score": float(whistle_series[idx]),
                    "click_score": float(click_series[idx]),
                    "count_score": float(transient_series[idx]),
                    "whistle_pred": int(whistle_pred[idx]),
                    "click_pred": int(click_pred[idx]),
                }
            )

        window_df = pd.DataFrame(rows)
        whistle_intervals_df = self._merge_positive_windows(window_df, "whistle_pred")
        click_intervals_df = self._merge_positive_windows(window_df, "click_pred")
        per_minute_df = self._per_minute_summary(window_df)

        summary_cards = [
            self._card("Whistle-band hotspots", int(window_df["whistle_pred"].sum()), "Candidate windows from lower-band activity"),
            self._card("Click-band hotspots", int(window_df["click_pred"].sum()), "Candidate windows from high-band activity"),
            self._card("Candidate whistle segments", len(whistle_intervals_df), "Merged lower-band activity windows"),
            self._card("Candidate click segments", len(click_intervals_df), "Merged high-band activity windows"),
            self._card("Transient index", round(float(window_df["count_score"].sum()), 1), "Scaled upper-band transient proxy"),
            self._card("Mean whistle-band activity", round(float(window_df["whistle_score"].mean()), 3), "Relative lower-band activity"),
            self._card("Mean click-band activity", round(float(window_df["click_score"].mean()), 3), "Relative upper-band activity"),
        ]

        return {
            "mode": "preview",
            "mode_label": "Acoustic preview",
            "headline": "Band-limited acoustic screening preview",
            "window_df": window_df,
            "whistle_intervals_df": whistle_intervals_df,
            "click_intervals_df": click_intervals_df,
            "per_minute_df": per_minute_df,
            "summary_cards": summary_cards,
            "series": self._series_payload(
                window_df,
                whistle_label="Whistle-band activity",
                click_label="Click-band activity",
                count_label="Transient index",
            ),
        }

    def _preview_window_scores(self, wave: np.ndarray, sr: int) -> tuple[float, float, float]:
        nperseg = min(1024, len(wave))
        if nperseg < 64:
            energy = float(np.mean(np.square(wave)))
            return energy, energy, 0.0

        noverlap = int(nperseg * 0.75)
        freqs, _, spec = signal.spectrogram(
            wave,
            fs=sr,
            window="hann",
            nperseg=nperseg,
            noverlap=noverlap,
            detrend=False,
            mode="magnitude",
        )
        spec = np.log10(spec + 1e-8)

        whistle_mask = (freqs >= 3000) & (freqs <= min(10000, sr / 2.0))
        click_mask = (freqs >= 10000) & (freqs <= min(40000, sr / 2.0))

        whistle_score = float(spec[whistle_mask].mean()) if np.any(whistle_mask) else float(spec.mean())
        click_score = float(spec[click_mask].mean()) if np.any(click_mask) else float(spec.mean())

        if np.any(click_mask) and spec.shape[1] > 1:
            click_band = spec[click_mask]
            transient = float(np.maximum(0.0, np.diff(click_band, axis=1)).mean())
        else:
            transient = 0.0

        return whistle_score, click_score, transient

    def _build_spectrogram_preview(self, audio_path: Path, output_path: Path) -> None:
        with sf.SoundFile(str(audio_path), "r") as handle:
            sr = handle.samplerate
            excerpt_sec = min(12.0, float(handle.frames) / float(sr))
            sample_count = max(1, int(round(excerpt_sec * sr)))
            wave = handle.read(sample_count, dtype="float32", always_2d=False)
        if getattr(wave, "ndim", 1) > 1:
            wave = wave.mean(axis=1)

        nperseg = min(2048, len(wave))
        noverlap = int(nperseg * 0.75)
        freqs, times, spec = signal.spectrogram(
            wave,
            fs=sr,
            window="hann",
            nperseg=nperseg,
            noverlap=noverlap,
            detrend=False,
            mode="magnitude",
        )
        top_khz = min(48.0, sr / 2000.0)
        mask = freqs <= top_khz * 1000.0
        spec_db = 10.0 * np.log10(spec[mask] + 1e-10)

        fig, ax = plt.subplots(figsize=(10, 4.2), dpi=160)
        ax.imshow(
            spec_db,
            origin="lower",
            aspect="auto",
            extent=[0.0, times[-1] if len(times) else excerpt_sec, freqs[mask][0] / 1000.0, freqs[mask][-1] / 1000.0],
            cmap="magma",
        )
        ax.axhspan(3.0, min(10.0, top_khz), color="#32a88c", alpha=0.12)
        ax.axhspan(10.0, min(40.0, top_khz), color="#d96b39", alpha=0.10)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Frequency (kHz)")
        ax.set_title("Spectrogram excerpt")
        for spine in ax.spines.values():
            spine.set_visible(False)
        fig.tight_layout()
        fig.savefig(output_path, bbox_inches="tight")
        plt.close(fig)

    def _evaluate_predictions(
        self,
        window_df: pd.DataFrame,
        whistle_csv: Path | None,
        click_csv: Path | None,
    ) -> dict[str, Any] | None:
        whistle_intervals = self._load_whistle_intervals(whistle_csv)
        click_times = self._load_click_times(click_csv)
        if not whistle_intervals and not click_times:
            return None

        eval_df = window_df.copy()
        eval_df["whistle_true"] = [
            self._window_whistle_label(float(row.start_time_s), float(row.end_time_s), whistle_intervals)
            for row in eval_df.itertuples(index=False)
        ]
        eval_df["click_true"] = [
            self._window_click_label(float(row.start_time_s), float(row.end_time_s), click_times)
            for row in eval_df.itertuples(index=False)
        ]
        eval_df["click_count_true"] = [
            self._window_click_count(float(row.start_time_s), float(row.end_time_s), click_times)
            for row in eval_df.itertuples(index=False)
        ]

        whistle_metrics = self._binary_metrics(
            eval_df["whistle_true"].to_numpy(),
            eval_df["whistle_score"].to_numpy(),
            threshold=0.70,
        )
        click_metrics = self._binary_metrics(
            eval_df["click_true"].to_numpy(),
            eval_df["click_score"].to_numpy(),
            threshold=0.45,
        )
        count_metrics = self._count_metrics(
            eval_df["click_count_true"].to_numpy(),
            eval_df["count_score"].to_numpy(),
        )

        return {
            "whistle": whistle_metrics,
            "click": click_metrics,
            "click_count": count_metrics,
        }

    def _binary_metrics(self, y_true: np.ndarray, y_score: np.ndarray, threshold: float) -> dict[str, Any]:
        y_pred = (y_score >= threshold).astype(int)
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            average="binary",
            zero_division=0,
        )
        roc_auc = None
        pr_auc = None
        if len(np.unique(y_true)) == 2:
            roc_auc = float(roc_auc_score(y_true, y_score))
            pr_auc = float(average_precision_score(y_true, y_score))
        return {
            "precision": round(float(precision), 3),
            "recall": round(float(recall), 3),
            "f1": round(float(f1), 3),
            "roc_auc": None if roc_auc is None else round(roc_auc, 3),
            "pr_auc": None if pr_auc is None else round(pr_auc, 3),
        }

    def _count_metrics(self, y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, Any]:
        mae = float(np.mean(np.abs(y_pred - y_true)))
        rmse = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
        total_error = float(np.sum(y_pred) - np.sum(y_true))
        pearson_r = None
        if len(y_true) > 1 and np.std(y_true) > 0 and np.std(y_pred) > 0:
            pearson_r = float(np.corrcoef(y_true, y_pred)[0, 1])
        return {
            "mae": round(mae, 3),
            "rmse": round(rmse, 3),
            "total_error": round(total_error, 3),
            "pearson_r": None if pearson_r is None else round(pearson_r, 3),
        }

    def _series_payload(
        self,
        window_df: pd.DataFrame,
        whistle_label: str,
        click_label: str,
        count_label: str,
    ) -> dict[str, Any]:
        sampled = self._downsample_dataframe(window_df, max_points=240)
        return {
            "time_s": [round(float(value), 2) for value in sampled["start_time_s"]],
            "whistle": [round(float(value), 4) for value in sampled["whistle_score"]],
            "click": [round(float(value), 4) for value in sampled["click_score"]],
            "count": [round(float(value), 4) for value in sampled["count_score"]],
            "labels": {
                "whistle": whistle_label,
                "click": click_label,
                "count": count_label,
            },
        }

    def _per_minute_summary(self, window_df: pd.DataFrame) -> pd.DataFrame:
        per_min = window_df.copy()
        per_min["minute_idx"] = (per_min["start_time_s"] // 60).astype(int)
        grouped = (
            per_min.groupby("minute_idx")
            .agg(
                whistle_windows=("whistle_pred", "sum"),
                click_windows=("click_pred", "sum"),
                mean_whistle_score=("whistle_score", "mean"),
                mean_click_score=("click_score", "mean"),
                count_total=("count_score", "sum"),
            )
            .reset_index()
        )
        return grouped

    def _table_rows(self, frame: pd.DataFrame) -> list[dict[str, Any]]:
        rows = []
        for row in frame.head(12).itertuples(index=False):
            rows.append(
                {
                    "start": self._format_seconds(float(row.start_time_s)),
                    "end": self._format_seconds(float(row.end_time_s)),
                    "duration": round(float(row.duration_s), 2),
                    "windows": int(row.n_windows),
                }
            )
        return rows

    def _per_minute_rows(self, frame: pd.DataFrame) -> list[dict[str, Any]]:
        rows = []
        for row in frame.head(12).itertuples(index=False):
            rows.append(
                {
                    "minute": int(row.minute_idx),
                    "whistles": int(round(float(row.whistle_windows))),
                    "clicks": int(round(float(row.click_windows))),
                    "whistle_mean": round(float(row.mean_whistle_score), 3),
                    "click_mean": round(float(row.mean_click_score), 3),
                    "count_total": round(float(row.count_total), 2),
                }
            )
        return rows

    def _downsample_dataframe(self, frame: pd.DataFrame, max_points: int) -> pd.DataFrame:
        if len(frame) <= max_points:
            return frame
        positions = np.linspace(0, len(frame) - 1, max_points).astype(int)
        return frame.iloc[positions].reset_index(drop=True)

    def _merge_positive_windows(self, frame: pd.DataFrame, pred_col: str) -> pd.DataFrame:
        positive = frame[frame[pred_col] == 1].copy()
        if positive.empty:
            return pd.DataFrame(columns=["start_time_s", "end_time_s", "duration_s", "n_windows"])

        out = []
        current_start = None
        current_end = None
        n_windows = 0
        previous_end = None

        for row in positive.itertuples(index=False):
            start = float(row.start_time_s)
            end = float(row.end_time_s)
            if current_start is None:
                current_start, current_end, n_windows = start, end, 1
            elif previous_end is not None and abs(start - previous_end) <= 1e-9:
                current_end = end
                n_windows += 1
            else:
                out.append(
                    {
                        "start_time_s": current_start,
                        "end_time_s": current_end,
                        "duration_s": current_end - current_start,
                        "n_windows": n_windows,
                    }
                )
                current_start, current_end, n_windows = start, end, 1
            previous_end = end

        out.append(
            {
                "start_time_s": current_start,
                "end_time_s": current_end,
                "duration_s": current_end - current_start,
                "n_windows": n_windows,
            }
        )
        return pd.DataFrame(out)

    def _sigmoid_scale(self, values: np.ndarray) -> np.ndarray:
        center = float(np.median(values))
        mad = float(np.median(np.abs(values - center)))
        spread = 1.4826 * mad if mad > 1e-6 else float(values.std())
        spread = spread if spread > 1e-6 else 1.0
        z = (values - center) / spread
        return 1.0 / (1.0 + np.exp(-z))

    def _positive_scale(self, values: np.ndarray) -> np.ndarray:
        center = float(np.median(values))
        mad = float(np.median(np.abs(values - center)))
        spread = 1.4826 * mad if mad > 1e-6 else float(values.std())
        spread = spread if spread > 1e-6 else 1.0
        z = np.maximum(0.0, (values - center) / spread)
        return z * 4.0

    def _card(self, label: str, value: Any, caption: str) -> dict[str, Any]:
        return {"label": label, "value": value, "caption": caption}

    def _build_audio_notes(self, audio_meta: dict[str, Any]) -> list[str]:
        notes = []
        if audio_meta["sample_rate_hz"] < 96000:
            notes.append(
                "This recording is below 96 kHz, so upper-band click interpretation is band-limited."
            )
        if audio_meta["channels"] > 1:
            notes.append("Multi-channel audio is averaged to mono before screening.")
        return notes

    def _load_whistle_intervals(self, path: Path | None) -> list[tuple[float, float]]:
        if path is None or not path.exists():
            return []
        frame = pd.read_csv(path)
        start_col = self._pick_first_existing(
            frame.columns,
            ["start_time_s", "start_s", "Begin Time (s)", "begin_time_s", "start"],
        )
        end_col = self._pick_first_existing(
            frame.columns,
            ["end_time_s", "end_s", "End Time (s)", "end_time_s", "end"],
        )
        if start_col is None or end_col is None:
            return []
        out = []
        for start, end in zip(frame[start_col], frame[end_col]):
            start_value = float(start)
            end_value = float(end)
            if end_value > start_value:
                out.append((start_value, end_value))
        return out

    def _load_click_times(self, path: Path | None) -> list[float]:
        if path is None or not path.exists():
            return []
        frame = pd.read_csv(path)
        time_col = self._pick_first_existing(
            frame.columns,
            ["click_time_s", "time_s", "onset_time_s", "event_time_s", "start_time_s", "time", "onset"],
        )
        if time_col is None:
            return []
        return [float(value) for value in frame[time_col].tolist()]

    def _pick_first_existing(self, columns: list[str], candidates: list[str]) -> str | None:
        lowered = {column.lower(): column for column in columns}
        for candidate in candidates:
            if candidate.lower() in lowered:
                return lowered[candidate.lower()]
        return None

    def _window_whistle_label(
        self,
        start_s: float,
        end_s: float,
        intervals: list[tuple[float, float]],
    ) -> int:
        for interval_start, interval_end in intervals:
            if max(start_s, interval_start) < min(end_s, interval_end):
                return 1
        return 0

    def _window_click_label(self, start_s: float, end_s: float, click_times: list[float]) -> int:
        for click_time in click_times:
            if start_s <= click_time < end_s:
                return 1
        return 0

    def _window_click_count(self, start_s: float, end_s: float, click_times: list[float]) -> int:
        return int(sum(start_s <= click_time < end_s for click_time in click_times))

    def _torch_ready(self) -> tuple[bool, str | None]:
        try:
            import torch  # noqa: F401
        except Exception as exc:
            return False, f"{exc.__class__.__name__}: {exc}"
        return True, None

    def _model_loader_ready(self) -> tuple[bool, str | None]:
        try:
            if str(self.model_repo_dir) not in sys.path:
                sys.path.insert(0, str(self.model_repo_dir))
            from dual_band_pam_vit_lite.model import DualBandPAMViTLite

            DualBandPAMViTLite.from_checkpoint(str(self.default_checkpoint))
        except Exception as exc:
            return False, f"{exc.__class__.__name__}: {exc}"
        return True, None

    def _format_seconds(self, seconds: float) -> str:
        total_seconds = max(0, int(round(seconds)))
        hours, remainder = divmod(total_seconds, 3600)
        minutes, secs = divmod(remainder, 60)
        if hours:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"
