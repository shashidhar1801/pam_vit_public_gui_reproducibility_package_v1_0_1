let activityChart = null;

function formatMetricValue(value) {
  if (value === null || value === undefined) return "-";
  return `${value}`;
}

function setMessage(message, isError = false) {
  const box = document.getElementById("form-message");
  if (!message) {
    box.classList.add("hidden");
    box.textContent = "";
    return;
  }
  box.classList.remove("hidden");
  box.textContent = message;
  box.style.background = isError ? "rgba(217, 96, 58, 0.12)" : "rgba(186, 141, 23, 0.12)";
  box.style.color = isError ? "#8a3117" : "#6f5607";
}

function renderNotes(notes) {
  const container = document.getElementById("results-notes");
  container.innerHTML = "";
  (notes || []).forEach((note) => {
    const item = document.createElement("div");
    item.className = "note";
    item.textContent = note;
    container.appendChild(item);
  });
}

function renderCards(cards) {
  const grid = document.getElementById("summary-grid");
  grid.innerHTML = "";
  (cards || []).forEach((card) => {
    const article = document.createElement("article");
    article.className = "metric-card";
    article.innerHTML = `
      <div class="metric-label">${card.label}</div>
      <div class="metric-value">${formatMetricValue(card.value)}</div>
      <div class="metric-caption">${card.caption}</div>
    `;
    grid.appendChild(article);
  });
}

function renderTableRows(targetId, rows) {
  const body = document.getElementById(targetId);
  body.innerHTML = "";
  if (!rows || !rows.length) {
    body.innerHTML = `<tr><td class="empty-row" colspan="4">No segments returned for this run.</td></tr>`;
    return;
  }
  rows.forEach((row) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.start}</td>
      <td>${row.end}</td>
      <td>${row.duration}</td>
      <td>${row.windows}</td>
    `;
    body.appendChild(tr);
  });
}

function renderDownloads(downloads) {
  const list = document.getElementById("download-list");
  list.innerHTML = "";
  (downloads || []).forEach((item) => {
    const link = document.createElement("a");
    link.className = "download-link";
    link.href = item.url;
    link.textContent = item.label;
    list.appendChild(link);
  });
}

function renderEvaluation(evaluation) {
  const band = document.getElementById("evaluation-band");
  const whistleList = document.getElementById("whistle-eval");
  const clickList = document.getElementById("click-eval");
  const countList = document.getElementById("count-eval");

  if (!evaluation) {
    band.classList.add("hidden");
    whistleList.innerHTML = "";
    clickList.innerHTML = "";
    countList.innerHTML = "";
    return;
  }

  band.classList.remove("hidden");
  const sections = [
    [whistleList, evaluation.whistle],
    [clickList, evaluation.click],
    [countList, evaluation.click_count],
  ];

  sections.forEach(([target, values]) => {
    target.innerHTML = "";
    Object.entries(values || {}).forEach(([key, value]) => {
      const li = document.createElement("li");
      li.textContent = `${key.replaceAll("_", " ")}: ${value === null ? "-" : value}`;
      target.appendChild(li);
    });
  });
}

function renderChart(series) {
  const context = document.getElementById("activity-chart");
  if (activityChart) {
    activityChart.destroy();
  }

  activityChart = new Chart(context, {
    type: "line",
    data: {
      labels: series.time_s,
      datasets: [
        {
          label: series.labels.whistle,
          data: series.whistle,
          borderColor: "#0c7c74",
          backgroundColor: "rgba(12, 124, 116, 0.14)",
          borderWidth: 2,
          tension: 0.3,
          pointRadius: 0,
        },
        {
          label: series.labels.click,
          data: series.click,
          borderColor: "#d4603a",
          backgroundColor: "rgba(212, 96, 58, 0.14)",
          borderWidth: 2,
          tension: 0.3,
          pointRadius: 0,
        },
        {
          label: series.labels.count,
          data: series.count,
          borderColor: "#ba8d17",
          backgroundColor: "rgba(186, 141, 23, 0.14)",
          borderWidth: 2,
          tension: 0.24,
          pointRadius: 0,
          borderDash: [7, 5],
        },
      ],
    },
    options: {
      maintainAspectRatio: false,
      interaction: {
        mode: "index",
        intersect: false,
      },
      plugins: {
        legend: {
          position: "top",
          labels: {
            usePointStyle: true,
            boxWidth: 8,
          },
        },
      },
      scales: {
        x: {
          title: {
            display: true,
            text: "Time (s)",
          },
          grid: {
            display: false,
          },
        },
        y: {
          beginAtZero: true,
          grid: {
            color: "rgba(199, 213, 203, 0.45)",
          },
        },
      },
    },
  });
}

function applyResults(payload) {
  document.getElementById("results-band").classList.remove("hidden");
  document.getElementById("results-title").textContent = payload.headline;
  document.getElementById("run-chip").textContent = `${payload.mode_label} | ${payload.audio.filename}`;
  document.getElementById("spectrogram-image").src = payload.spectrogram_url;

  renderNotes(payload.notes);
  renderCards(payload.summary_cards);
  renderDownloads(payload.downloads);
  renderTableRows("whistle-rows", payload.intervals.whistles);
  renderTableRows("click-rows", payload.intervals.clicks);
  renderEvaluation(payload.evaluation);
  renderChart(payload.series);

  document.getElementById("results-band").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function submitAnalysis(event) {
  event.preventDefault();
  setMessage("Running analysis...");

  const form = document.getElementById("analysis-form");
  const button = document.getElementById("submit-button");
  const data = new FormData(form);

  button.disabled = true;
  button.textContent = "Analyzing...";

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      body: data,
    });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "Analysis did not finish.");
    }
    setMessage("");
    applyResults(payload);
  } catch (error) {
    setMessage(error.message, true);
  } finally {
    button.disabled = false;
    button.textContent = "Analyze recording";
  }
}

function resetForm() {
  document.getElementById("analysis-form").reset();
  setMessage("");
}

window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("analysis-form").addEventListener("submit", submitAnalysis);
  document.getElementById("reset-button").addEventListener("click", resetForm);
});
