# PAM-ViT Public GUI

This project packages the Taiwanese white dolphin PAM workflow as a public-facing web application.
End users only need a browser. They do not need to run Python or the model code on their own
machine.

## What it does

- Accepts WAV files and ZIP archives that contain a WAV file
- Screens recordings for whistle and click activity
- Exports window predictions, merged intervals, per-minute summaries, and a JSON run summary
- Scores the run against optional whistle and click reference CSV files
- Falls back to a clearly labeled acoustic preview mode when the manuscript checkpoint is not
  attached to the deployment

## Modes

### 1. Live manuscript model

When all of these are present, the app runs real Dual-Band PAM-ViT-Lite inference:

- a compatible PyTorch runtime
- `models/dual_band_pam_vit_lite_final.pt` or `PAM_VIT_CHECKPOINT`
- `model_repo/configs/adaptation_stage.yaml` or `PAM_VIT_CONFIG`

### 2. Acoustic preview

When the checkpoint or PyTorch runtime is missing, the app stays usable by returning:

- band-limited whistle activity
- band-limited click activity
- upper-band transient proxy values
- merged candidate segments

This preview mode is intentionally honest about what it is. It does not claim to be the final
manuscript model.

## Project layout

```text
pam_vit_public_app/
├── app.py
├── services.py
├── static/
│   ├── css/styles.css
│   ├── img/
│   └── js/app.js
├── templates/index.html
├── model_repo/
├── models/
├── runs/
├── requirements.txt
└── Dockerfile
```

## Run locally

If Flask is already available in your environment:

```bash
cd /Users/shashidhars/Documents/Codex/2026-04-20-files-mentioned-by-the-user-methods/pam_vit_public_app
python3 app.py
```

Then open:

- [http://127.0.0.1:8000](http://127.0.0.1:8000)

## Install dependencies

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

PyTorch is not pinned in `requirements.txt` because the correct install command depends on whether
the public deployment is CPU-only or GPU-backed. Install a matching PyTorch build separately for
the target runtime.

## Attach the final checkpoint

Place the manuscript checkpoint here:

```text
models/dual_band_pam_vit_lite_final.pt
```

Or set environment variables:

```bash
export PAM_VIT_CHECKPOINT=/absolute/path/to/dual_band_pam_vit_lite_final.pt
export PAM_VIT_CONFIG=/absolute/path/to/adaptation_stage.yaml
```

## Public deployment

This app is designed for hosted deployment on a service that runs Python web apps. Public users
will only see the GUI.

Typical deployment choices:

- a small VM
- a container host
- a managed Python app platform

For production:

- install a matching PyTorch runtime
- attach the final checkpoint
- persist or periodically clean the `runs/` directory
- run behind `gunicorn`

## Notes for manuscript release

- `model_repo/` contains the copied Dual-Band PAM-ViT-Lite reference code
- `static/img/` contains public-facing thumbnails derived from the supplied architecture and results
  PPTX files
- the GUI is intentionally usable before the final checkpoint is shipped, which makes it easier to
  review and refine the public experience before the model artifact is finalized
