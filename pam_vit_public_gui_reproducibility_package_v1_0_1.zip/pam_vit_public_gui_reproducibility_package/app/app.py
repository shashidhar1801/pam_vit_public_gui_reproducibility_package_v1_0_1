from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, abort, jsonify, render_template, request, send_file

from services import PAMPublicService


BASE_DIR = Path(__file__).resolve().parent

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024

service = PAMPublicService(BASE_DIR)


@app.get("/")
def index():
    return render_template("index.html", runtime=service.status())


@app.get("/api/status")
def api_status():
    return jsonify(service.status())


@app.post("/api/analyze")
def api_analyze():
    audio_file = request.files.get("audio_file")
    if audio_file is None or not audio_file.filename:
        return jsonify({"error": "Upload a WAV file or a ZIP that contains a WAV file."}), 400

    whistle_csv = request.files.get("whistle_csv")
    click_csv = request.files.get("click_csv")

    try:
        result = service.analyze_upload(audio_file, whistle_csv=whistle_csv, click_csv=click_csv)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": f"Analysis did not finish cleanly: {exc}"}), 500
    return jsonify(result)


@app.get("/runs/<run_id>/<path:filename>")
def run_file(run_id: str, filename: str):
    target = service.resolve_run_file(run_id, filename)
    if target is None:
        abort(404)
    return send_file(target, as_attachment=request.args.get("download") == "1")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    app.run(host="0.0.0.0", port=port, debug=False)
