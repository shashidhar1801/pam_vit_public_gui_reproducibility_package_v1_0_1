# Dual-Band PAM-ViT-Lite

GitHub-ready reference code for the **operational Dual-Band PAM-ViT-Lite** model used to detect
Taiwanese white dolphin **whistles** and **clicks** from passive acoustic monitoring (PAM) data.

This repository focuses on the model that was actually used in the main experiments:

- **whistles:** 3–10 kHz
- **clicks:** 10–40 kHz
- **final dense-scene operating window:** 0.25 s
- **click micro-windows:** 4

The code is written to be readable first and fast second. That is intentional. Reproducibility is
more important here than micro-optimizing every line.

---

## Repository layout

```text
dual_band_pam_vit_lite_github/
├── dual_band_pam_vit_lite/
│   ├── __init__.py
│   ├── config.py
│   ├── dataset.py
│   ├── features.py
│   ├── labels.py
│   ├── metrics.py
│   ├── model.py
│   └── utils.py
├── scripts/
│   ├── build_window_table.py
│   ├── train_dual_band_pam_vit_lite.py
│   ├── mine_hard_negatives.py
│   ├── infer_dual_band_pam_vit_lite.py
│   ├── evaluate_dual_band_pam_vit_lite.py
│   └── run_staged_training.py
├── configs/
│   ├── base_stage.yaml
│   ├── hard_negative_stage.yaml
│   └── adaptation_stage.yaml
├── examples/
│   ├── example_recordings_manifest.csv
│   └── README.md
├── Dockerfile
├── requirements.txt
└── GUIDE.md
```

---

## What this repository provides

1. **Model definition** for Dual-Band PAM-ViT-Lite.
2. **Feature extraction** for whistle and click branches.
3. **Window-table generation** from WAV files and annotation CSVs.
4. **Training scripts** for staged training.
5. **Hard-negative mining** for shrimp-heavy negative data.
6. **Inference scripts** for WAV and ZIP inputs.
7. **Evaluation scripts** for window-level and count-level metrics.

---

## Installation

### Option A: standard Python environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH=$(pwd)
```

### Option B: Docker

```bash
docker build -t dual-band-pam-vit-lite .
docker run --rm -it -v $(pwd):/workspace dual-band-pam-vit-lite
```

---

## Data conventions

The repository expects **96 kHz WAV files** for full whistle + click operation.

If a file has a lower sample rate, whistle detection may still be usable, but click detection will be
band-limited and should not be interpreted in the same way as the 96 kHz model outputs.

### Recording manifest format

Use a CSV like this:

```csv
audio_path,split,role,whistle_csv,click_csv,subtype_csv,duplicate_factor
/path/to/file.wav,train,mixed,/path/to/whistles.csv,/path/to/clicks.csv,/path/to/subtypes.csv,1
```

#### Required columns

- `audio_path`
- `split` (`train`, `val`, `test`)
- `role` (for example: `whistle_only`, `click_only`, `mixed`, `noise`, `hard_negative`)

#### Optional columns

- `whistle_csv`
- `click_csv`
- `subtype_csv`
- `duplicate_factor`

### Whistle annotation CSV

The code accepts common variants of these columns:

- `start_time_s` / `start_s` / `Begin Time (s)`
- `end_time_s` / `end_s` / `End Time (s)`

### Click annotation CSV

The code accepts common variants of these columns:

- `click_time_s`
- `time_s`
- `onset_time_s`
- `event_time_s`
- `start_time_s`

---

## Recommended staged workflow

### Step 1. Build a window table

```bash
python scripts/build_window_table.py \
  --manifest /path/to/recordings_manifest.csv \
  --config configs/base_stage.yaml \
  --output /path/to/base_windows.csv
```

This creates one row per analysis window with:

- audio path
- start and end time
- whistle label
- click label
- click count
- optional subtype label

### Step 2. Split the window table

Split the window table into:

- `base_train_windows.csv`
- `base_val_windows.csv`
- `base_test_windows.csv`

Do this **without temporal leakage**. Keep blocks from the same continuous file together whenever
possible.

### Step 3. Train the base model

```bash
python scripts/train_dual_band_pam_vit_lite.py --config configs/base_stage.yaml
```

### Step 4. Mine shrimp-heavy hard negatives

```bash
python scripts/mine_hard_negatives.py \
  --config configs/hard_negative_stage.yaml \
  --checkpoint outputs/base_stage/dual_band_pam_vit_lite_base_best.pt \
  --windows-csv /path/to/hard_negative_train_windows.csv \
  --top-fraction 0.20 \
  --duplicate-times 2 \
  --output /path/to/hard_negative_train_windows_mined.csv
```

This scores negative windows with the click head and duplicates the most click-like 20% of them.
That mirrors the hard-negative strategy used in the manuscript.

### Step 5. Train the hard-negative refinement stage

```bash
python scripts/train_dual_band_pam_vit_lite.py --config configs/hard_negative_stage.yaml
```

### Step 6. Train the dense-scene adaptation stage

```bash
python scripts/train_dual_band_pam_vit_lite.py --config configs/adaptation_stage.yaml
```

This final stage uses the **0.25 s** operating window for dense mixed-event scenes.

---

## Inference on a new WAV or ZIP

```bash
python scripts/infer_dual_band_pam_vit_lite.py \
  --config configs/adaptation_stage.yaml \
  --checkpoint /path/to/final_checkpoint.pt \
  --input /path/to/file.wav.zip \
  --output-dir /path/to/inference_outputs
```

Outputs include:

- `*_window_predictions.csv`
- `*_whistle_intervals.csv`
- `*_click_intervals.csv`
- `*_per_minute_summary.csv`
- `*_summary.json`

### Important note about the count head

The click-count head outputs a **regression estimate**. That value is useful for density trends and
count-based evaluation, but it should **not** be confused with the thresholded interval count.

If you need a clean event total for reporting, use the **merged click intervals** or a separately
validated click-event matching procedure.

---

## Evaluation with annotations

```bash
python scripts/evaluate_dual_band_pam_vit_lite.py \
  --predictions /path/to/file_window_predictions.csv \
  --whistle-csv /path/to/file_whistles.csv \
  --click-csv /path/to/file_clicks.csv \
  --output /path/to/evaluation_report.json
```

The evaluation script reports:

- whistle precision / recall / F1
- click precision / recall / F1
- confusion matrices
- count MAE / RMSE / Pearson correlation / total count error

---

## Suggested GitHub release package

For a journal submission, I recommend including:

1. this code repository,
2. the final YAML configs,
3. the final checkpoint path or download link,
4. a small synthetic example manifest,
5. a short `CHANGELOG.md` if you continue to iterate.

---

## Citation note

If you upload this repository publicly, describe it as the **operational Dual-Band PAM-ViT-Lite
implementation used for the main manuscript experiments**. If you later add the full dense
encoder-decoder version, keep it in a separate module so readers do not confuse the conceptual
model with the experimentally used one.

---

## Questions other users will probably ask

### Why are whistles and clicks separated before the model?
Because they occupy different frequency bands and have very different signal geometry. A single
flat encoder is a poor fit for this task.

### Why does the click branch use micro-windows?
Because click timing is short, dense, and local. The branch needs finer temporal structure than the
whistle branch.

### Why can the click-count output stay nonzero on negative files?
Because the count head is a regression head. It can leak low positive values even when the binary
click head stays below threshold.

### Why does the repository use CSV manifests and window tables?
Because PAM datasets are messy. Keeping every step as an explicit CSV makes the pipeline easier
for other groups to inspect, audit, and adapt.
