from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, confusion_matrix, precision_recall_fscore_support, roc_auc_score


@dataclass
class BinaryMetrics:
    precision: float
    recall: float
    f1: float
    roc_auc: float | None
    pr_auc: float | None
    confusion_matrix: List[List[int]]


@dataclass
class CountMetrics:
    mae: float
    rmse: float
    pearson_r: float | None
    total_error: float


def compute_binary_metrics(y_true: np.ndarray, y_prob: np.ndarray, threshold: float) -> BinaryMetrics:
    y_pred = (y_prob >= threshold).astype(int)
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="binary", zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist()

    roc = None
    pr = None
    if len(np.unique(y_true)) == 2:
        roc = float(roc_auc_score(y_true, y_prob))
        pr = float(average_precision_score(y_true, y_prob))

    return BinaryMetrics(
        precision=float(p),
        recall=float(r),
        f1=float(f1),
        roc_auc=roc,
        pr_auc=pr,
        confusion_matrix=cm,
    )


def compute_count_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> CountMetrics:
    mae = float(np.mean(np.abs(y_pred - y_true)))
    rmse = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
    total_error = float(np.sum(y_pred) - np.sum(y_true))
    r = None
    if len(y_true) > 1 and np.std(y_true) > 0 and np.std(y_pred) > 0:
        r = float(np.corrcoef(y_true, y_pred)[0, 1])
    return CountMetrics(mae=mae, rmse=rmse, pearson_r=r, total_error=total_error)


def merge_positive_windows_to_intervals(df: pd.DataFrame, pred_col: str) -> pd.DataFrame:
    pos = df[df[pred_col] == 1].copy()
    if pos.empty:
        return pd.DataFrame(columns=["start_time_s", "end_time_s", "duration_s", "n_windows"])

    out = []
    cur_s = cur_e = None
    nwin = 0
    prev_end = None
    for row in pos.itertuples(index=False):
        s = float(row.start_time_s)
        e = float(row.end_time_s)
        if cur_s is None:
            cur_s, cur_e, nwin = s, e, 1
        elif abs(s - prev_end) <= 1e-9:
            cur_e = e
            nwin += 1
        else:
            out.append({"start_time_s": cur_s, "end_time_s": cur_e, "duration_s": cur_e - cur_s, "n_windows": nwin})
            cur_s, cur_e, nwin = s, e, 1
        prev_end = e
    out.append({"start_time_s": cur_s, "end_time_s": cur_e, "duration_s": cur_e - cur_s, "n_windows": nwin})
    return pd.DataFrame(out)
