from __future__ import annotations

from dataclasses import fields
from typing import Dict, Tuple

import torch
import torch.nn as nn

from .config import ModelConfig


class PatchEmbed(nn.Module):
    """Small helper that turns a feature map into patch tokens.

    We use a convolution here because it is fast, simple, and easy for others to modify.
    """

    def __init__(self, in_channels: int, embed_dim: int, patch_size: Tuple[int, int]):
        super().__init__()
        self.proj = nn.Conv2d(
            in_channels,
            embed_dim,
            kernel_size=patch_size,
            stride=patch_size,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # [B, C, H, W] -> [B, N, D]
        return self.proj(x).flatten(2).transpose(1, 2)


class ResidualSelfAttentionBlock(nn.Module):
    """A light Transformer block used in both branches."""

    def __init__(self, dim: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True, dropout=dropout)
        self.ln2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 2, dim),
            nn.Dropout(dropout),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y, _ = self.attn(self.ln1(x), self.ln1(x), self.ln1(x), need_weights=False)
        x = x + self.dropout(y)
        x = x + self.ff(self.ln2(x))
        return x


class ResidualCrossAttentionBlock(nn.Module):
    """Cross-attention block for whistle-click interaction.

    The code is intentionally compact. The manuscript already carries the full math; here we focus
    on something people can run and inspect without much friction.
    """

    def __init__(self, dim: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        self.ln_q = nn.LayerNorm(dim)
        self.ln_kv = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True, dropout=dropout)
        self.ln2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 2, dim),
            nn.Dropout(dropout),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, query: torch.Tensor, key_value: torch.Tensor) -> torch.Tensor:
        y, _ = self.attn(self.ln_q(query), self.ln_kv(key_value), self.ln_kv(key_value), need_weights=False)
        query = query + self.dropout(y)
        query = query + self.ff(self.ln2(query))
        return query


class DualBandPAMViTLite(nn.Module):
    """Operational Dual-Band PAM-ViT-Lite model.

    Inputs
    ------
    whistle_x : [B, 3, H_w, W_w]
    click_x   : [B, K, 2, H_c, W_c]

    Outputs
    -------
    whistle_logit : [B]
    click_logit   : [B]
    count_logit   : [B]  (transformed with expm1 at inference time)
    subtype_logit : [B, num_subtypes] when enabled
    """

    def __init__(
        self,
        whistle_hw: Tuple[int, int],
        click_hw: Tuple[int, int],
        num_micro_windows: int,
        model_cfg: ModelConfig,
    ):
        super().__init__()
        self.model_cfg = model_cfg
        self.whistle_hw = whistle_hw
        self.click_hw = click_hw
        self.num_micro_windows = num_micro_windows

        patch = model_cfg.patch_size
        embed_dim = model_cfg.embed_dim
        heads = model_cfg.num_heads
        dropout = model_cfg.dropout

        num_whistle_tokens = (whistle_hw[0] // patch[0]) * (whistle_hw[1] // patch[1])
        num_click_tokens = (click_hw[0] // patch[0]) * (click_hw[1] // patch[1])

        self.whistle_patch = PatchEmbed(3, embed_dim, patch)
        self.click_patch = PatchEmbed(2, embed_dim, patch)

        self.whistle_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.click_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.whistle_pos = nn.Parameter(torch.zeros(1, num_whistle_tokens + 1, embed_dim))
        self.click_pos = nn.Parameter(torch.zeros(1, num_click_tokens + 1, embed_dim))
        self.temporal_pos = nn.Parameter(torch.zeros(1, num_micro_windows, embed_dim))

        self.whistle_blocks = nn.ModuleList(
            [ResidualSelfAttentionBlock(embed_dim, heads, dropout) for _ in range(model_cfg.whistle_blocks)]
        )
        self.click_blocks = nn.ModuleList(
            [ResidualSelfAttentionBlock(embed_dim, heads, dropout) for _ in range(model_cfg.click_blocks)]
        )
        self.temporal_block = ResidualSelfAttentionBlock(embed_dim, heads, dropout)

        self.whistle_to_click = ResidualCrossAttentionBlock(embed_dim, heads, dropout)
        self.click_to_whistle = ResidualCrossAttentionBlock(embed_dim, heads, dropout)

        self.whistle_head = nn.Linear(embed_dim, 1)
        self.click_head = nn.Linear(embed_dim, 1)
        self.count_head = nn.Linear(embed_dim, 1)

        if model_cfg.use_subtype_head:
            if model_cfg.num_subtypes <= 0:
                raise ValueError("num_subtypes must be > 0 when use_subtype_head=True")
            self.subtype_head = nn.Linear(embed_dim * 2, model_cfg.num_subtypes)
        else:
            self.subtype_head = None

    def forward(self, whistle_x: torch.Tensor, click_x: torch.Tensor) -> Dict[str, torch.Tensor]:
        # ----- Whistle branch -----
        bsz = whistle_x.shape[0]
        whistle_tokens = self.whistle_patch(whistle_x)
        whistle_tokens = torch.cat([self.whistle_cls.expand(bsz, -1, -1), whistle_tokens], dim=1)
        whistle_tokens = whistle_tokens + self.whistle_pos[:, : whistle_tokens.shape[1]]
        for block in self.whistle_blocks:
            whistle_tokens = block(whistle_tokens)
        whistle_summary = whistle_tokens[:, :1]

        # ----- Click branch -----
        bsz, num_micro, channels, height, width = click_x.shape
        click_flat = click_x.reshape(bsz * num_micro, channels, height, width)
        click_tokens = self.click_patch(click_flat)
        click_tokens = torch.cat([self.click_cls.expand(bsz * num_micro, -1, -1), click_tokens], dim=1)
        click_tokens = click_tokens + self.click_pos[:, : click_tokens.shape[1]]
        for block in self.click_blocks:
            click_tokens = block(click_tokens)
        click_summary = click_tokens[:, 0].reshape(bsz, num_micro, -1)
        click_summary = self.temporal_block(click_summary + self.temporal_pos[:, :num_micro])

        # ----- Cross-band fusion -----
        whistle_summary = self.whistle_to_click(whistle_summary, click_summary)
        click_summary = self.click_to_whistle(click_summary, whistle_tokens)

        whistle_global = whistle_summary.squeeze(1)
        click_global = click_summary.mean(dim=1)
        joint = torch.cat([whistle_global, click_global], dim=-1)

        out: Dict[str, torch.Tensor] = {
            "whistle_logit": self.whistle_head(whistle_global).squeeze(-1),
            "click_logit": self.click_head(click_global).squeeze(-1),
            "count_logit": self.count_head(click_global).squeeze(-1),
        }
        if self.subtype_head is not None:
            out["subtype_logit"] = self.subtype_head(joint)
        return out

    def save_checkpoint(self, path: str, extra: Dict | None = None) -> None:
        payload = {
            "model_state_dict": self.state_dict(),
            "wh_hw": list(self.whistle_hw),
            "cl_hw": list(self.click_hw),
            "num_micro": self.num_micro_windows,
            "model_config": self.model_cfg.__dict__,
        }
        if extra:
            payload.update(extra)
        torch.save(payload, path)

    @classmethod
    def from_checkpoint(cls, path: str) -> "DualBandPAMViTLite":
        ckpt = torch.load(path, map_location="cpu")
        raw_cfg = dict(ckpt.get("model_config", {}))
        if isinstance(raw_cfg.get("patch_size"), list):
            raw_cfg["patch_size"] = tuple(raw_cfg["patch_size"])
        allowed = {field.name for field in fields(ModelConfig)}
        model_cfg = ModelConfig(**{key: value for key, value in raw_cfg.items() if key in allowed})
        model = cls(tuple(ckpt["wh_hw"]), tuple(ckpt["cl_hw"]), int(ckpt["num_micro"]), model_cfg)
        raw_state = ckpt["model_state_dict"]
        replacements = [
            ("wh_patch.", "whistle_patch."),
            ("wh_cls", "whistle_cls"),
            ("wh_pos", "whistle_pos"),
            ("wh_blocks.", "whistle_blocks."),
            ("cl_patch.", "click_patch."),
            ("cl_cls", "click_cls"),
            ("cl_pos", "click_pos"),
            ("cl_blocks.", "click_blocks."),
            ("temp_pos", "temporal_pos"),
            ("temp_block.", "temporal_block."),
            ("w2c.", "whistle_to_click."),
            ("c2w.", "click_to_whistle."),
            ("wh_head.", "whistle_head."),
            ("cl_head.", "click_head."),
        ]
        remapped_state = {}
        for key, value in raw_state.items():
            new_key = key
            for old_prefix, new_prefix in replacements:
                if new_key.startswith(old_prefix):
                    new_key = new_prefix + new_key[len(old_prefix):]
                    break
            new_key = new_key.replace(".lnq.", ".ln_q.")
            new_key = new_key.replace(".lnkv.", ".ln_kv.")
            remapped_state[new_key] = value
        model.load_state_dict(remapped_state)
        return model
