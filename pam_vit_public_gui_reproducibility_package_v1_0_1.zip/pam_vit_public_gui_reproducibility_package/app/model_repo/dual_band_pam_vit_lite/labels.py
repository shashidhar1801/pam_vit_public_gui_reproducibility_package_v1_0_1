from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


def _pick_first_existing(columns: Iterable[str], candidates: Iterable[str]) -> Optional[str]:
    cols = {c.lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in cols:
            return cols[cand.lower()]
    return None


def load_whistle_intervals(path: str | None) -> List[Tuple[float, float]]:
    """Load whistle intervals from a CSV.

    We accept a few column-name variants because every lab seems to have its own naming habits.
    """
    if path is None or str(path).strip() == "" or not Path(path).exists():
        return []
    df = pd.read_csv(path)
    start_col = _pick_first_existing(df.columns, ["start_time_s", "start_s", "begin time (s)", "begin_time_s", "start"])
    end_col = _pick_first_existing(df.columns, ["end_time_s", "end_s", "end time (s)", "end_time_s", "end"])
    if start_col is None or end_col is None:
        raise ValueError(f"Could not find whistle interval columns in {path}.")
    out = []
    for s, e in zip(df[start_col], df[end_col]):
        s = float(s)
        e = float(e)
        if e > s:
            out.append((s, e))
    return out


def load_click_times(path: str | None) -> List[float]:
    if path is None or str(path).strip() == "" or not Path(path).exists():
        return []
    df = pd.read_csv(path)
    time_col = _pick_first_existing(
        df.columns,
        ["click_time_s", "time_s", "onset_time_s", "event_time_s", "start_time_s", "time", "onset"],
    )
    if time_col is None:
        raise ValueError(f"Could not find click time column in {path}.")
    return [float(x) for x in df[time_col].tolist()]


def load_whistle_subtypes(path: str | None) -> Dict[Tuple[float, float], str]:
    """Optional whistle subtype map keyed by interval.

    This stays simple on purpose. If a lab wants something richer later, they can swap in a more
    exact interval-matching strategy.
    """
    if path is None or str(path).strip() == "" or not Path(path).exists():
        return {}
    df = pd.read_csv(path)
    start_col = _pick_first_existing(df.columns, ["start_time_s", "start_s", "begin time (s)", "start"])
    end_col = _pick_first_existing(df.columns, ["end_time_s", "end_s", "end time (s)", "end"])
    type_col = _pick_first_existing(df.columns, ["type", "subtype", "whistle_type", "label"])
    if start_col is None or end_col is None or type_col is None:
        return {}
    out: Dict[Tuple[float, float], str] = {}
    for s, e, t in zip(df[start_col], df[end_col], df[type_col]):
        out[(float(s), float(e))] = str(t)
    return out


def window_whistle_label(start_s: float, end_s: float, intervals: List[Tuple[float, float]]) -> int:
    for s, e in intervals:
        if max(start_s, s) < min(end_s, e):
            return 1
    return 0


def window_click_label(start_s: float, end_s: float, click_times: List[float]) -> int:
    for t in click_times:
        if start_s <= t < end_s:
            return 1
    return 0


def window_click_count(start_s: float, end_s: float, click_times: List[float]) -> int:
    return int(sum(start_s <= t < end_s for t in click_times))
