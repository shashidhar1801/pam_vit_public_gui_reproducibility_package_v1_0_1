from __future__ import annotations

from typing import Tuple

import numpy as np
import scipy.signal as signal
import torch
import torch.nn.functional as F

from .config import FeatureConfig


def _resize2d(arr: np.ndarray, out_hw: Tuple[int, int]) -> np.ndarray:
    """Resize a 2D array with bilinear interpolation.

    Torch handles this nicely, and using it here keeps the training and inference paths identical.
    """
    t = torch.from_numpy(arr.astype(np.float32))[None, None]
    t = F.interpolate(t, size=out_hw, mode="bilinear", align_corners=False)
    return t[0, 0].cpu().numpy()


def _zscore(x: np.ndarray) -> np.ndarray:
    return (x - x.mean()) / (x.std() + 1e-6)


def whistle_features(wave: np.ndarray, sr: int, cfg: FeatureConfig) -> np.ndarray:
    """Build the 3-channel whistle tensor.

    Channels
    --------
    1. Raw log-magnitude
    2. Frequency-wise median-centered log-magnitude
    3. Temporal difference
    """
    f, _, S = signal.spectrogram(
        wave,
        fs=sr,
        window="hann",
        nperseg=cfg.whistle_nperseg,
        noverlap=cfg.whistle_noverlap,
        detrend=False,
        mode="magnitude",
    )
    band = (f >= cfg.whistle_band_hz[0]) & (f <= cfg.whistle_band_hz[1])
    S = np.log10(S[band] + 1e-8)

    raw = S
    background_suppressed = S - np.median(S, axis=1, keepdims=True)
    temporal_diff = np.diff(S, axis=1, prepend=S[:, :1])

    channels = []
    for ch in (raw, background_suppressed, temporal_diff):
        resized = _resize2d(ch, cfg.whistle_hw)
        channels.append(_zscore(resized).astype(np.float32))
    return np.stack(channels, axis=0)


def click_features(wave: np.ndarray, sr: int, cfg: FeatureConfig) -> np.ndarray:
    """Build the click tensor sequence.

    We split the input window into four equal micro-windows. That choice follows the final model
    used in the manuscript and gives the click branch a bit more temporal agility.
    """
    n = len(wave)
    edges = np.linspace(0, n, cfg.num_micro_windows + 1, dtype=int)
    micro_tensors = []
    for k in range(cfg.num_micro_windows):
        xk = wave[edges[k] : edges[k + 1]]
        f, _, S = signal.spectrogram(
            xk,
            fs=sr,
            window="hann",
            nperseg=cfg.click_nperseg,
            noverlap=cfg.click_noverlap,
            detrend=False,
            mode="magnitude",
        )
        band = (f >= cfg.click_band_hz[0]) & (f <= cfg.click_band_hz[1])
        S = np.log10(S[band] + 1e-8)
        raw = S
        positive_diff = np.maximum(0.0, np.diff(S, axis=1, prepend=S[:, :1]))
        channels = []
        for ch in (raw, positive_diff):
            resized = _resize2d(ch, cfg.click_hw)
            channels.append(_zscore(resized).astype(np.float32))
        micro_tensors.append(np.stack(channels, axis=0))
    return np.stack(micro_tensors, axis=0)
