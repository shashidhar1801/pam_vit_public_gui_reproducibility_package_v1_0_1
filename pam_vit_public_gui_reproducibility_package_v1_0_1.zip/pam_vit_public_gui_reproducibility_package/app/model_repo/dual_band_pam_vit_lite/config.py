from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import yaml


@dataclass
class FeatureConfig:
    """Signal-preprocessing choices for the operational model.

    These defaults match the final 0.25 s challenge-adapted checkpoint used in the manuscript.
    We keep them explicit here so other groups can change them without digging through scripts.
    """

    sample_rate_hz: int = 96_000
    whistle_band_hz: Tuple[int, int] = (3000, 10000)
    click_band_hz: Tuple[int, int] = (10000, 40000)
    window_sec: float = 0.25
    stride_sec: float = 0.25
    num_micro_windows: int = 4
    whistle_nperseg: int = 256
    whistle_noverlap: int = 192
    click_nperseg: int = 64
    click_noverlap: int = 48
    whistle_hw: Tuple[int, int] = (16, 32)
    click_hw: Tuple[int, int] = (16, 32)


@dataclass
class ModelConfig:
    """Architecture settings for Dual-Band PAM-ViT-Lite."""

    embed_dim: int = 32
    num_heads: int = 4
    whistle_blocks: int = 2
    click_blocks: int = 2
    dropout: float = 0.10
    patch_size: Tuple[int, int] = (4, 4)
    use_subtype_head: bool = False
    num_subtypes: int = 0


@dataclass
class TrainingConfig:
    """Optimization and dataloader settings.

    The defaults are intentionally conservative. They are meant to run reliably on a single GPU
    and to be readable for others who want to reproduce the staged workflow.
    """

    batch_size: int = 32
    num_epochs: int = 30
    learning_rate: float = 3e-4
    weight_decay: float = 1e-4
    grad_clip_norm: float = 5.0
    random_seed: int = 42
    num_workers: int = 0
    pos_weight_whistle: float = 1.0
    pos_weight_click: float = 1.0
    lambda_whistle: float = 1.0
    lambda_click: float = 1.0
    lambda_count: float = 0.25
    lambda_subtype: float = 0.15
    patience: int = 8
    monitor_metric: str = "joint_score"
    mixed_precision: bool = False


@dataclass
class ExperimentConfig:
    """Top-level experiment container."""

    name: str = "dual_band_pam_vit_lite"
    stage: str = "base"
    feature: FeatureConfig = field(default_factory=FeatureConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    train_windows_csv: Optional[str] = None
    val_windows_csv: Optional[str] = None
    test_windows_csv: Optional[str] = None
    output_dir: str = "outputs"
    resume_checkpoint: Optional[str] = None
    threshold_whistle: float = 0.70
    threshold_click: float = 0.45

    @staticmethod
    def _merge_dataclass(dc_cls, src: Optional[Dict[str, Any]]):
        if src is None:
            return dc_cls()
        base = dc_cls().__dict__.copy()
        base.update(src)
        return dc_cls(**base)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "ExperimentConfig":
        with open(path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
        feature = cls._merge_dataclass(FeatureConfig, raw.get("feature"))
        model = cls._merge_dataclass(ModelConfig, raw.get("model"))
        training = cls._merge_dataclass(TrainingConfig, raw.get("training"))
        top = {k: v for k, v in raw.items() if k not in {"feature", "model", "training"}}
        obj = cls(feature=feature, model=model, training=training, **top)
        return obj

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "stage": self.stage,
            "feature": self.feature.__dict__,
            "model": self.model.__dict__,
            "training": self.training.__dict__,
            "train_windows_csv": self.train_windows_csv,
            "val_windows_csv": self.val_windows_csv,
            "test_windows_csv": self.test_windows_csv,
            "output_dir": self.output_dir,
            "resume_checkpoint": self.resume_checkpoint,
            "threshold_whistle": self.threshold_whistle,
            "threshold_click": self.threshold_click,
        }
