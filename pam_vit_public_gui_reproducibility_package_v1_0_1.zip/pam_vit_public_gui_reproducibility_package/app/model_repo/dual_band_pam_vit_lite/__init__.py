"""Dual-Band PAM-ViT-Lite.

A lightweight, reproducible implementation of the operational model used in the manuscript.
"""

from .config import ExperimentConfig, FeatureConfig, ModelConfig, TrainingConfig
from .model import DualBandPAMViTLite

__all__ = [
    "DualBandPAMViTLite",
    "ExperimentConfig",
    "FeatureConfig",
    "ModelConfig",
    "TrainingConfig",
]
