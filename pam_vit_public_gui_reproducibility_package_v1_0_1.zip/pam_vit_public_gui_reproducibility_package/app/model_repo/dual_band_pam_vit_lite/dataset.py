from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import soundfile as sf
import torch
from torch.utils.data import Dataset

from .config import FeatureConfig
from .features import click_features, whistle_features
from .labels import (
    load_click_times,
    load_whistle_intervals,
    load_whistle_subtypes,
    window_click_count,
    window_click_label,
    window_whistle_label,
)


@dataclass
class WindowRecord:
    audio_path: str
    split: str
    role: str
    start_time_s: float
    end_time_s: float
    whistle_label: int
    click_label: int
    click_count: int
    duplicate_factor: int = 1
    subtype_label: Optional[str] = None


SUBTYPE_TO_ID_DEFAULT = {
    "flat": 0,
    "upsweep": 1,
    "downsweep": 2,
    "arch": 3,
    "u_shape": 4,
    "s_shape": 5,
    "wavy": 6,
    "step": 7,
    "complex": 8,
}


def build_window_table_from_manifest(manifest_csv: str, feature_cfg: FeatureConfig, out_csv: Optional[str] = None) -> pd.DataFrame:
    """Turn a recording manifest into a window-level training table.

    Manifest columns
    ----------------
    audio_path, split, role, whistle_csv, click_csv, subtype_csv, duplicate_factor

    The function is intentionally plain CSV-in / CSV-out. That makes it easy to inspect, version,
    and share on GitHub.
    """
    manifest = pd.read_csv(manifest_csv)
    rows: List[Dict] = []

    for rec in manifest.itertuples(index=False):
        audio_path = Path(str(rec.audio_path))
        split = str(getattr(rec, "split", "train"))
        role = str(getattr(rec, "role", "unspecified"))
        whistle_csv = getattr(rec, "whistle_csv", None)
        click_csv = getattr(rec, "click_csv", None)
        subtype_csv = getattr(rec, "subtype_csv", None)
        duplicate_factor = int(getattr(rec, "duplicate_factor", 1) or 1)

        intervals = load_whistle_intervals(whistle_csv)
        click_times = load_click_times(click_csv)
        subtype_map = load_whistle_subtypes(subtype_csv)

        info = sf.info(str(audio_path))
        duration = float(info.duration)
        starts = np.arange(0.0, max(0.0, duration - feature_cfg.window_sec) + 1e-9, feature_cfg.stride_sec)

        for s in starts:
            e = float(s + feature_cfg.window_sec)
            y_w = window_whistle_label(float(s), e, intervals)
            y_c = window_click_label(float(s), e, click_times)
            n_c = window_click_count(float(s), e, click_times)

            subtype_label = None
            if y_w == 1 and subtype_map:
                for (si, ei), lab in subtype_map.items():
                    if max(s, si) < min(e, ei):
                        subtype_label = lab
                        break

            rows.append(
                {
                    "audio_path": str(audio_path),
                    "split": split,
                    "role": role,
                    "start_time_s": float(s),
                    "end_time_s": e,
                    "whistle_label": int(y_w),
                    "click_label": int(y_c),
                    "click_count": int(n_c),
                    "duplicate_factor": duplicate_factor,
                    "subtype_label": subtype_label,
                }
            )

    df = pd.DataFrame(rows)
    if out_csv is not None:
        df.to_csv(out_csv, index=False)
    return df


class WindowTableDataset(Dataset):
    """On-the-fly feature dataset built from a window table.

    The implementation leans toward readability rather than clever caching tricks. For a journal
    release, that is usually the better trade-off.
    """

    def __init__(self, windows_csv: str, feature_cfg: FeatureConfig, subtype_to_id: Optional[Dict[str, int]] = None):
        self.df = pd.read_csv(windows_csv)
        self.feature_cfg = feature_cfg
        self.subtype_to_id = subtype_to_id or SUBTYPE_TO_ID_DEFAULT

        expanded_rows = []
        for row in self.df.itertuples(index=False):
            dup = int(getattr(row, "duplicate_factor", 1) or 1)
            for _ in range(max(1, dup)):
                expanded_rows.append(row)
        self.rows = expanded_rows

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.rows[idx]
        audio_path = str(row.audio_path)
        start_s = float(row.start_time_s)
        end_s = float(row.end_time_s)

        with sf.SoundFile(audio_path, "r") as fobj:
            sr = fobj.samplerate
            n_samples = int(round((end_s - start_s) * sr))
            fobj.seek(int(round(start_s * sr)))
            wave = fobj.read(n_samples, dtype="float32", always_2d=False)
            if getattr(wave, "ndim", 1) > 1:
                wave = wave.mean(axis=1)
            if len(wave) < n_samples:
                wave = np.pad(wave, (0, n_samples - len(wave)))

        whistle_x = whistle_features(wave, sr, self.feature_cfg)
        click_x = click_features(wave, sr, self.feature_cfg)

        subtype_id = -1
        subtype_label = getattr(row, "subtype_label", None)
        if isinstance(subtype_label, str) and subtype_label in self.subtype_to_id:
            subtype_id = self.subtype_to_id[subtype_label]

        return {
            "whistle_x": torch.from_numpy(whistle_x),
            "click_x": torch.from_numpy(click_x),
            "whistle_label": torch.tensor(float(row.whistle_label), dtype=torch.float32),
            "click_label": torch.tensor(float(row.click_label), dtype=torch.float32),
            "click_count": torch.tensor(float(row.click_count), dtype=torch.float32),
            "subtype_id": torch.tensor(int(subtype_id), dtype=torch.long),
            "audio_path": audio_path,
            "start_time_s": torch.tensor(float(start_s), dtype=torch.float32),
            "end_time_s": torch.tensor(float(end_s), dtype=torch.float32),
        }
