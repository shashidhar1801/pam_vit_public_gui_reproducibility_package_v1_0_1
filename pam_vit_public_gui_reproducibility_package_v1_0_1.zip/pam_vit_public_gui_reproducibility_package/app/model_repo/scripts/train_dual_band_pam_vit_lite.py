#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Optional

import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from dual_band_pam_vit_lite.config import ExperimentConfig
from dual_band_pam_vit_lite.dataset import WindowTableDataset, SUBTYPE_TO_ID_DEFAULT
from dual_band_pam_vit_lite.metrics import compute_binary_metrics, compute_count_metrics
from dual_band_pam_vit_lite.model import DualBandPAMViTLite
from dual_band_pam_vit_lite.utils import AverageMeter, ensure_dir, set_seed, write_json


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train Dual-Band PAM-ViT-Lite from window CSV files.")
    p.add_argument("--config", required=True, help="Experiment YAML config.")
    return p.parse_args()


def build_model(cfg: ExperimentConfig) -> DualBandPAMViTLite:
    return DualBandPAMViTLite(
        whistle_hw=cfg.feature.whistle_hw,
        click_hw=cfg.feature.click_hw,
        num_micro_windows=cfg.feature.num_micro_windows,
        model_cfg=cfg.model,
    )


def compute_loss(batch: Dict[str, torch.Tensor], out: Dict[str, torch.Tensor], cfg: ExperimentConfig, device: torch.device) -> Dict[str, torch.Tensor]:
    # We keep the loss explicit because this script is meant for readers, not just for a GPU.
    whistle_target = batch["whistle_label"].to(device)
    click_target = batch["click_label"].to(device)
    count_target = batch["click_count"].to(device)

    bce_wh = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([cfg.training.pos_weight_whistle], device=device))
    bce_cl = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([cfg.training.pos_weight_click], device=device))

    loss_wh = bce_wh(out["whistle_logit"], whistle_target)
    loss_cl = bce_cl(out["click_logit"], click_target)
    count_pred = torch.expm1(out["count_logit"]).clamp(min=0)
    loss_count = nn.SmoothL1Loss()(count_pred, count_target)

    total = (
        cfg.training.lambda_whistle * loss_wh
        + cfg.training.lambda_click * loss_cl
        + cfg.training.lambda_count * loss_count
    )

    loss_subtype = torch.tensor(0.0, device=device)
    if cfg.model.use_subtype_head and "subtype_logit" in out:
        subtype_id = batch["subtype_id"].to(device)
        valid = subtype_id >= 0
        if valid.any():
            loss_subtype = nn.CrossEntropyLoss()(out["subtype_logit"][valid], subtype_id[valid])
            total = total + cfg.training.lambda_subtype * loss_subtype

    return {
        "total": total,
        "whistle": loss_wh.detach(),
        "click": loss_cl.detach(),
        "count": loss_count.detach(),
        "subtype": loss_subtype.detach(),
    }


def run_epoch(model, loader, optimizer, cfg, device, train: bool):
    model.train(train)
    meter = AverageMeter()
    all_wh_true, all_wh_prob = [], []
    all_cl_true, all_cl_prob = [], []
    all_count_true, all_count_pred = [], []

    iterator = tqdm(loader, desc="train" if train else "val", leave=False)
    for batch in iterator:
        whistle_x = batch["whistle_x"].to(device)
        click_x = batch["click_x"].to(device)
        out = model(whistle_x, click_x)
        losses = compute_loss(batch, out, cfg, device)

        if train:
            optimizer.zero_grad(set_to_none=True)
            losses["total"].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.grad_clip_norm)
            optimizer.step()

        batch_size = whistle_x.shape[0]
        meter.update(float(losses["total"].item()), batch_size)

        wh_prob = torch.sigmoid(out["whistle_logit"]).detach().cpu().numpy()
        cl_prob = torch.sigmoid(out["click_logit"]).detach().cpu().numpy()
        ct_pred = torch.expm1(out["count_logit"]).clamp(min=0).detach().cpu().numpy()

        all_wh_prob.extend(wh_prob.tolist())
        all_cl_prob.extend(cl_prob.tolist())
        all_count_pred.extend(ct_pred.tolist())
        all_wh_true.extend(batch["whistle_label"].numpy().tolist())
        all_cl_true.extend(batch["click_label"].numpy().tolist())
        all_count_true.extend(batch["click_count"].numpy().tolist())

        iterator.set_postfix(loss=f"{meter.avg:.4f}")

    wh = compute_binary_metrics(
        y_true=torch.tensor(all_wh_true).numpy(),
        y_prob=torch.tensor(all_wh_prob).numpy(),
        threshold=cfg.threshold_whistle,
    )
    cl = compute_binary_metrics(
        y_true=torch.tensor(all_cl_true).numpy(),
        y_prob=torch.tensor(all_cl_prob).numpy(),
        threshold=cfg.threshold_click,
    )
    cnt = compute_count_metrics(
        y_true=torch.tensor(all_count_true).numpy(),
        y_pred=torch.tensor(all_count_pred).numpy(),
    )

    # One practical summary score keeps checkpoint selection simple.
    joint_score = wh.f1 + cl.f1 - 0.01 * cnt.mae

    metrics = {
        "loss": meter.avg,
        "whistle_precision": wh.precision,
        "whistle_recall": wh.recall,
        "whistle_f1": wh.f1,
        "click_precision": cl.precision,
        "click_recall": cl.recall,
        "click_f1": cl.f1,
        "count_mae": cnt.mae,
        "count_rmse": cnt.rmse,
        "count_pearson_r": cnt.pearson_r,
        "joint_score": joint_score,
    }
    return metrics


def main() -> None:
    args = parse_args()
    cfg = ExperimentConfig.from_yaml(args.config)
    output_dir = ensure_dir(cfg.output_dir)
    set_seed(cfg.training.random_seed)

    train_ds = WindowTableDataset(cfg.train_windows_csv, cfg.feature)
    val_ds = WindowTableDataset(cfg.val_windows_csv, cfg.feature)
    train_loader = DataLoader(train_ds, batch_size=cfg.training.batch_size, shuffle=True, num_workers=cfg.training.num_workers)
    val_loader = DataLoader(val_ds, batch_size=cfg.training.batch_size, shuffle=False, num_workers=cfg.training.num_workers)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg).to(device)
    if cfg.resume_checkpoint:
        state = torch.load(cfg.resume_checkpoint, map_location=device)
        model.load_state_dict(state["model_state_dict"])

    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.training.learning_rate, weight_decay=cfg.training.weight_decay)

    history = []
    best_score = float("-inf")
    best_path = output_dir / f"{cfg.name}_{cfg.stage}_best.pt"
    epochs_without_improvement = 0

    for epoch in range(1, cfg.training.num_epochs + 1):
        train_metrics = run_epoch(model, train_loader, optimizer, cfg, device, train=True)
        val_metrics = run_epoch(model, val_loader, optimizer, cfg, device, train=False)

        row = {"epoch": epoch}
        row.update({f"train_{k}": v for k, v in train_metrics.items()})
        row.update({f"val_{k}": v for k, v in val_metrics.items()})
        history.append(row)

        current = float(val_metrics[cfg.training.monitor_metric])
        if current > best_score:
            best_score = current
            epochs_without_improvement = 0
            model.save_checkpoint(
                str(best_path),
                extra={
                    "feature_config": cfg.feature.__dict__,
                    "training_config": cfg.training.__dict__,
                    "window_sec": cfg.feature.window_sec,
                    "stride_sec": cfg.feature.stride_sec,
                    "thresholds": {"whistle": cfg.threshold_whistle, "click": cfg.threshold_click},
                    "best_val_metrics": val_metrics,
                },
            )
        else:
            epochs_without_improvement += 1

        print(
            f"Epoch {epoch:03d} | train whistle F1={train_metrics['whistle_f1']:.3f} | "
            f"val whistle F1={val_metrics['whistle_f1']:.3f} | val click F1={val_metrics['click_f1']:.3f} | "
            f"val count MAE={val_metrics['count_mae']:.3f}"
        )

        if epochs_without_improvement >= cfg.training.patience:
            print(f"Stopping early after {epoch} epochs because validation stopped improving.")
            break

    history_df = pd.DataFrame(history)
    history_df.to_csv(output_dir / f"{cfg.name}_{cfg.stage}_history.csv", index=False)
    write_json(cfg.to_dict(), output_dir / f"{cfg.name}_{cfg.stage}_config.json")
    print(f"Saved best checkpoint to: {best_path}")
    print(f"Saved training history to: {output_dir}")


if __name__ == "__main__":
    main()
