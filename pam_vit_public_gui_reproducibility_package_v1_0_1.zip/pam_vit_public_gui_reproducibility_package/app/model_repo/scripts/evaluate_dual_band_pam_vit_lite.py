#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from dual_band_pam_vit_lite.labels import load_click_times, load_whistle_intervals, window_click_count, window_click_label, window_whistle_label
from dual_band_pam_vit_lite.metrics import compute_binary_metrics, compute_count_metrics, merge_positive_windows_to_intervals
from dual_band_pam_vit_lite.utils import write_json


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Evaluate window predictions against whistle/click annotations.")
    p.add_argument("--predictions", required=True, help="Window-level prediction CSV from the inference script.")
    p.add_argument("--whistle-csv", default=None, help="Reference whistle interval CSV.")
    p.add_argument("--click-csv", default=None, help="Reference click event CSV.")
    p.add_argument("--output", required=True, help="Output JSON report.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    pred = pd.read_csv(args.predictions)
    whistle_intervals = load_whistle_intervals(args.whistle_csv)
    click_times = load_click_times(args.click_csv)

    pred["whistle_true"] = pred.apply(lambda r: window_whistle_label(float(r.start_time_s), float(r.end_time_s), whistle_intervals), axis=1)
    pred["click_true"] = pred.apply(lambda r: window_click_label(float(r.start_time_s), float(r.end_time_s), click_times), axis=1)
    pred["click_count_true"] = pred.apply(lambda r: window_click_count(float(r.start_time_s), float(r.end_time_s), click_times), axis=1)

    whistle_metrics = compute_binary_metrics(pred["whistle_true"].to_numpy(), pred["whistle_prob"].to_numpy(), threshold=0.70)
    click_metrics = compute_binary_metrics(pred["click_true"].to_numpy(), pred["click_prob"].to_numpy(), threshold=0.45)
    count_metrics = compute_count_metrics(pred["click_count_true"].to_numpy(), pred["click_count_pred"].to_numpy())

    report = {
        "whistle": whistle_metrics.__dict__,
        "click": click_metrics.__dict__,
        "click_count": count_metrics.__dict__,
        "n_windows": int(len(pred)),
    }
    write_json(report, args.output)
    print(report)


if __name__ == "__main__":
    main()
