#!/usr/bin/env python3
from __future__ import annotations

import argparse

import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from dual_band_pam_vit_lite.config import ExperimentConfig
from dual_band_pam_vit_lite.dataset import WindowTableDataset
from dual_band_pam_vit_lite.model import DualBandPAMViTLite


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Score hard-negative windows and duplicate the most click-like ones.")
    p.add_argument("--config", required=True, help="Experiment YAML config.")
    p.add_argument("--checkpoint", required=True, help="Base checkpoint used for scoring.")
    p.add_argument("--windows-csv", required=True, help="Window CSV containing hard-negative rows.")
    p.add_argument("--top-fraction", type=float, default=0.20, help="Fraction of hardest windows to keep.")
    p.add_argument("--duplicate-times", type=int, default=2, help="How many extra copies to assign.")
    p.add_argument("--output", required=True, help="Augmented window CSV.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    cfg = ExperimentConfig.from_yaml(args.config)
    model = DualBandPAMViTLite.from_checkpoint(args.checkpoint)
    model.eval()
    ds = WindowTableDataset(args.windows_csv, cfg.feature)
    loader = DataLoader(ds, batch_size=32, shuffle=False)

    probs = []
    for batch in tqdm(loader, desc="Scoring hard negatives"):
        with torch.no_grad():
            out = model(batch["whistle_x"], batch["click_x"])
            probs.extend(torch.sigmoid(out["click_logit"]).cpu().numpy().tolist())

    df = pd.read_csv(args.windows_csv)
    # We only mine from windows that are actually negative and marked as hard-negative files.
    mask = (
        (df["role"].astype(str).str.contains("hard", case=False, na=False))
        & (df["whistle_label"] == 0)
        & (df["click_label"] == 0)
    )
    score_series = pd.Series(probs[: len(df)], index=df.index)
    candidate_scores = score_series[mask]
    cutoff = candidate_scores.quantile(1.0 - args.top_fraction) if len(candidate_scores) else None

    df["mined_click_prob"] = score_series
    df["duplicate_factor"] = df.get("duplicate_factor", 1)
    if cutoff is not None:
        hard_mask = mask & (df["mined_click_prob"] >= cutoff)
        df.loc[hard_mask, "duplicate_factor"] = df.loc[hard_mask, "duplicate_factor"].astype(int) + int(args.duplicate_times)

    df.to_csv(args.output, index=False)
    print(f"Saved mined hard-negative window table to {args.output}")


if __name__ == "__main__":
    main()
