#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run the base -> hard-negative -> adaptation workflow.")
    p.add_argument("--base-config", required=True)
    p.add_argument("--hard-config", required=True)
    p.add_argument("--adapt-config", required=True)
    p.add_argument("--hard-negative-windows", required=True, help="Window CSV for the hard-negative stage.")
    p.add_argument("--repo-root", default=".")
    return p.parse_args()


def run(cmd):
    print("\n>>>", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    args = parse_args()
    repo = Path(args.repo_root)

    train_script = str(repo / "scripts" / "train_dual_band_pam_vit_lite.py")
    mine_script = str(repo / "scripts" / "mine_hard_negatives.py")

    # Stage 1: base supervised training
    run(["python", train_script, "--config", args.base_config])

    # We expect the base config to save a best checkpoint in its output folder.
    # This is simple on purpose: people should be able to follow the lineage by reading filenames.
    base_cfg_name = Path(args.base_config).stem
    base_output = repo / "outputs" / base_cfg_name
    # If users keep a different output layout, they can adjust this path manually.

    # Stage 2: mine hard negatives and train the refinement stage.
    base_best = list((repo / "outputs").rglob("*_base_best.pt"))
    if not base_best:
        raise FileNotFoundError("Could not locate the base-stage checkpoint. Please check the output directory.")
    base_ckpt = str(sorted(base_best)[-1])
    mined_csv = str(Path(args.hard_negative_windows).with_name("hard_negative_windows_mined.csv"))
    run([
        "python", mine_script,
        "--config", args.hard_config,
        "--checkpoint", base_ckpt,
        "--windows-csv", args.hard_negative_windows,
        "--top-fraction", "0.20",
        "--duplicate-times", "2",
        "--output", mined_csv,
    ])
    run(["python", train_script, "--config", args.hard_config])

    # Stage 3: challenge adaptation.
    hard_best = list((repo / "outputs").rglob("*_hard_negative_best.pt"))
    if not hard_best:
        hard_best = list((repo / "outputs").rglob("*_hard_best.pt"))
    if not hard_best:
        raise FileNotFoundError("Could not locate the hard-negative checkpoint. Please check the output directory.")
    run(["python", train_script, "--config", args.adapt_config])


if __name__ == "__main__":
    main()
