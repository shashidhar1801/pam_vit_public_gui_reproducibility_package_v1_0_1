#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from dual_band_pam_vit_lite.config import ExperimentConfig
from dual_band_pam_vit_lite.dataset import build_window_table_from_manifest


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build a window-level CSV from a recording manifest.")
    p.add_argument("--manifest", required=True, help="Recording manifest CSV.")
    p.add_argument("--config", required=True, help="Experiment YAML config.")
    p.add_argument("--output", required=True, help="Where to save the window table CSV.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    cfg = ExperimentConfig.from_yaml(args.config)
    df = build_window_table_from_manifest(args.manifest, cfg.feature, out_csv=args.output)
    print(f"Built {len(df):,} windows -> {Path(args.output).resolve()}")


if __name__ == "__main__":
    main()
