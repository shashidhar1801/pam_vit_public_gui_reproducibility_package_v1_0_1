#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import soundfile as sf
import torch

from dual_band_pam_vit_lite.config import ExperimentConfig
from dual_band_pam_vit_lite.features import click_features, whistle_features
from dual_band_pam_vit_lite.metrics import merge_positive_windows_to_intervals
from dual_band_pam_vit_lite.model import DualBandPAMViTLite
from dual_band_pam_vit_lite.utils import ensure_dir, format_seconds, write_json


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run Dual-Band PAM-ViT-Lite on a WAV or ZIP file.")
    p.add_argument("--config", required=True, help="Experiment YAML config.")
    p.add_argument("--checkpoint", required=True, help="Model checkpoint path.")
    p.add_argument("--input", required=True, help="Input WAV or ZIP.")
    p.add_argument("--output-dir", required=True, help="Directory for reports and CSV files.")
    return p.parse_args()


def _resolve_audio(path: str, out_dir: Path) -> Path:
    p = Path(path)
    if p.suffix.lower() != ".zip":
        return p
    with zipfile.ZipFile(p, "r") as zf:
        wavs = [n for n in zf.namelist() if n.lower().endswith(".wav") and not n.startswith("__MACOSX/")]
        if not wavs:
            raise RuntimeError("No WAV file found in ZIP archive.")
        name = wavs[0]
        zf.extract(name, out_dir)
        return out_dir / name


def main() -> None:
    args = parse_args()
    cfg = ExperimentConfig.from_yaml(args.config)
    output_dir = ensure_dir(args.output_dir)
    audio_path = _resolve_audio(args.input, output_dir / "unzipped")

    model = DualBandPAMViTLite.from_checkpoint(args.checkpoint)
    model.eval()

    info = sf.info(str(audio_path))
    sr = info.samplerate
    duration = float(info.duration)
    starts = np.arange(0.0, max(0.0, duration - cfg.feature.window_sec) + 1e-9, cfg.feature.stride_sec)

    rows = []
    with sf.SoundFile(str(audio_path), "r") as fobj:
        n_samples = int(round(cfg.feature.window_sec * sr))
        for s in starts:
            fobj.seek(int(round(s * sr)))
            wave = fobj.read(n_samples, dtype="float32", always_2d=False)
            if getattr(wave, "ndim", 1) > 1:
                wave = wave.mean(axis=1)
            if len(wave) < n_samples:
                wave = np.pad(wave, (0, n_samples - len(wave)))

            whistle_x = torch.from_numpy(whistle_features(wave, sr, cfg.feature))[None]
            click_x = torch.from_numpy(click_features(wave, sr, cfg.feature))[None]
            with torch.no_grad():
                out = model(whistle_x, click_x)
                whistle_prob = torch.sigmoid(out["whistle_logit"])[0].item()
                click_prob = torch.sigmoid(out["click_logit"])[0].item()
                click_count = torch.expm1(out["count_logit"]).clamp(min=0)[0].item()

            rows.append(
                {
                    "start_time_s": float(s),
                    "end_time_s": float(s + cfg.feature.window_sec),
                    "whistle_prob": whistle_prob,
                    "click_prob": click_prob,
                    "whistle_pred": int(whistle_prob >= cfg.threshold_whistle),
                    "click_pred": int(click_prob >= cfg.threshold_click),
                    "click_count_pred": click_count,
                }
            )

    df = pd.DataFrame(rows)
    whistle_intervals = merge_positive_windows_to_intervals(df, "whistle_pred")
    click_intervals = merge_positive_windows_to_intervals(df, "click_pred")

    for out_df in (whistle_intervals, click_intervals):
        if len(out_df):
            out_df["start_hms"] = out_df["start_time_s"].map(format_seconds)
            out_df["end_hms"] = out_df["end_time_s"].map(format_seconds)

    per_min = df.copy()
    per_min["minute_idx"] = (per_min["start_time_s"] // 60).astype(int)
    per_min = (
        per_min.groupby("minute_idx")
        .agg(
            whistle_positive_windows=("whistle_pred", "sum"),
            click_positive_windows=("click_pred", "sum"),
            mean_whistle_prob=("whistle_prob", "mean"),
            mean_click_prob=("click_prob", "mean"),
            click_count_sum=("click_count_pred", "sum"),
        )
        .reset_index()
    )

    summary = {
        "file": audio_path.name,
        "duration_min": duration / 60.0,
        "samplerate_hz": sr,
        "window_sec": cfg.feature.window_sec,
        "stride_sec": cfg.feature.stride_sec,
        "whistle_positive_windows": int(df["whistle_pred"].sum()),
        "click_positive_windows": int(df["click_pred"].sum()),
        "predicted_whistle_intervals": int(len(whistle_intervals)),
        "predicted_click_intervals": int(len(click_intervals)),
        "predicted_total_click_count_head_sum": float(df["click_count_pred"].sum()),
        "mean_whistle_probability": float(df["whistle_prob"].mean()),
        "mean_click_probability": float(df["click_prob"].mean()),
    }

    stem = audio_path.stem.replace(" ", "_")
    df.to_csv(output_dir / f"{stem}_window_predictions.csv", index=False)
    whistle_intervals.to_csv(output_dir / f"{stem}_whistle_intervals.csv", index=False)
    click_intervals.to_csv(output_dir / f"{stem}_click_intervals.csv", index=False)
    per_min.to_csv(output_dir / f"{stem}_per_minute_summary.csv", index=False)
    write_json(summary, output_dir / f"{stem}_summary.json")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
