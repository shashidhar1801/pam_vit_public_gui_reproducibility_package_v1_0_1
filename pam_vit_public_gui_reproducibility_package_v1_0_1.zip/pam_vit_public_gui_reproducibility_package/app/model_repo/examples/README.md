# Example files

This folder contains *format examples*, not the original manuscript data.

- `example_recordings_manifest.csv` shows the expected recording-manifest layout.
- `base_train_windows.csv`, `base_val_windows.csv`, `hard_negative_train_windows.csv`, and the
  other window tables are not shipped because they depend on your local data paths.

Typical workflow:

1. Create your own recording manifest.
2. Build a window table with `scripts/build_window_table.py`.
3. Split the resulting window table into train / val / test CSV files.
4. Point the YAML configs to those CSV files.
