# Detailed usage guide for Dual-Band PAM-ViT-Lite

This guide is written for people who were **not** part of the original project.
The goal is to help someone go from raw WAV files to training, inference, and evaluation without
needing to reverse-engineer the manuscript.

## 1. Decide what you are trying to reproduce

There are two different things in the manuscript:

- **Dual-Band PAM-ViT**: the full conceptual architecture.
- **Dual-Band PAM-ViT-Lite**: the operational model used in the main experiments.

This repository implements **Dual-Band PAM-ViT-Lite**.

## 2. Prepare your audio

Use:

- WAV files
- 96 kHz sample rate whenever possible
- mono preferred, or stereo collapsed to mono in preprocessing

If your files are not 96 kHz, whistle detection may still work, but click detection will be band-limited.
That is not a bug; it is a physics issue.

## 3. Prepare your annotations

### Whistles
Use interval annotations with start and end times.

### Clicks
Use event-time annotations.

### Subtypes (optional)
Use them only if you want the auxiliary subtype head.
The model does not require them for whistle / click detection.

## 4. Build the recording manifest

The manifest answers a very practical question:
**which file belongs to which split, and where are its labels?**

A good habit is to keep one row per recording and make the split explicit.
That way, train / validation / test leakage is easy to spot.

## 5. Build window tables

The repository does not train directly from the raw manifest. Instead, it first converts each file into
window-level examples.

That may look like an extra step, but it is very useful because:

- you can inspect labels before training,
- you can stratify by case,
- you can save exactly what the model saw,
- and you can share those CSV files with coauthors for verification.

## 6. Train in stages

The staged training design is important.

### Stage A — base supervised training
Use ordinary whistle, click, mixed, and negative data.
This gives the model its initial separation ability.

### Stage B — hard-negative refinement
Use shrimp-heavy negatives to teach the click branch what **not** to fire on.
This matters because snapping shrimp are one of the hardest click confounds.

### Stage C — dense-scene adaptation
Use short 0.25 s windows on dense mixed-event material.
This is where the model learns not to collapse when whistles and clicks become crowded.

## 7. Run inference

The inference script accepts either a WAV or a ZIP containing a WAV.
It exports:

- window-level probabilities,
- merged whistle intervals,
- merged click intervals,
- per-minute summaries,
- and a JSON summary.

That is enough for both manuscript figures and operational screening.

## 8. Understand the outputs correctly

A few outputs are easy to misread.

### Whistle intervals and click intervals
These are thresholded interval-level outputs and are usually the best values to report as detected totals.

### Click-count head sum
This is **not** the same as the number of thresholded click detections.
It is a regression estimate of click density. It is useful, but it should be interpreted carefully.

## 9. Common mistakes to avoid

- Training and testing on adjacent windows from the same continuous file.
- Mixing weak labels and manual labels without tracking the source.
- Treating count-head output as exact click-event detection.
- Forgetting that lower-sample-rate files cannot support the full click band.
- Reporting file-level results without noting whether they came from short challenge files or long-term PAM.

## 10. Recommended GitHub release checklist

Before publishing the repository, check that you have included:

- `README.md`
- `GUIDE.md`
- the main YAML configs
- at least one example manifest
- training and inference scripts
- evaluation scripts
- a clear note about the final checkpoint used in the manuscript

If you want the release to be especially useful to others, also include:

- a diagram of the architecture,
- one example long-term inference output,
- and a short note on how to extend the model to new dolphin datasets.
